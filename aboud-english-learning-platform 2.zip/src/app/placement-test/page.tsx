"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import { playSoundEffect } from "@/lib/speech";
import confetti from "canvas-confetti";
import {
  Award,
  Sparkles,
  CheckCircle2,
  XCircle,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  BookOpen,
  GraduationCap,
  Loader2,
  Star,
  Check,
} from "lucide-react";

interface PlacementQuestion {
  id: number;
  type: string;
  level: string;
  promptEn: string;
  promptAr: string;
  options: string[];
  correctIndex: number;
  explanationAr: string;
}

const defaultPlacementQuestions: PlacementQuestion[] = [
  {
    id: 1,
    type: "multiple_choice",
    level: "Pre-A1",
    promptEn: "What is the capital letter of 'b'?",
    promptAr: "ما هو الحرف الكبير المطابق للحرف الصغير 'b'؟",
    options: ["D", "B", "P", "R"],
    correctIndex: 1,
    explanationAr: "الحرف الكبير للحرف b هو B. انتبه لعدم الخلط بين B و D.",
  },
  {
    id: 2,
    type: "multiple_choice",
    level: "A1",
    promptEn: "Choose the correct sentence:",
    promptAr: "اختر الجملة القواعدية الصحيحة:",
    options: ["He are a doctor.", "He is a doctor.", "He am a doctor.", "He be a doctor."],
    correctIndex: 1,
    explanationAr: "الضمير He يأخذ فعل الكينونة is في زمن المضارع: He is a doctor.",
  },
  {
    id: 3,
    type: "multiple_choice",
    level: "A1",
    promptEn: "I usually _____ coffee in the morning.",
    promptAr: "أنا عادةً _____ القهوة في الصباح.",
    options: ["drinks", "drink", "drinking", "drank"],
    correctIndex: 1,
    explanationAr: "مع الضمير I في المضارع البسيط نستخدم الفعل في المصدر بدون إضافة: I drink.",
  },
  {
    id: 4,
    type: "multiple_choice",
    level: "A1",
    promptEn: "Which word means 'كتاب' in English?",
    promptAr: "ما الكلمة الإنجليزية التي تعني 'كتاب'؟",
    options: ["Pen", "Door", "Book", "Desk"],
    correctIndex: 2,
    explanationAr: "Book تعني كتاب. Pen تعني قلم، Door يعني باب، Desk يعني مكتب.",
  },
  {
    id: 5,
    type: "multiple_choice",
    level: "A2",
    promptEn: "Yesterday, we ______ a fantastic movie at the cinema.",
    promptAr: "أمس، نحن ______ فيلماً رائعاً في السينما.",
    options: ["watch", "watched", "watching", "watches"],
    correctIndex: 1,
    explanationAr: "بما أن الجملة تبدأ بـ Yesterday الدالة على الماضي، نستخدم التصريف الماضي المنتظم Watched.",
  },
  {
    id: 6,
    type: "multiple_choice",
    level: "A2",
    promptEn: "Mount Everest is ______ mountain in the world.",
    promptAr: "جبل إيفرست هو الجبل _____ في العالم.",
    options: ["the higher", "the highest", "higher than", "highest"],
    correctIndex: 1,
    explanationAr: "في صيغة التفضيل العليا (Superlative) نستخدم the + الصفة + est: the highest.",
  },
  {
    id: 7,
    type: "multiple_choice",
    level: "B1",
    promptEn: "I have lived in this city ______ 2018.",
    promptAr: "عشت في هذه المدينة ______ عام 2018.",
    options: ["for", "since", "during", "ago"],
    correctIndex: 1,
    explanationAr: "نستخدم since عند ذكر نقطة بداية محددة للزمن (سنة محددة)، بينما نستخدم for للمدة الإجمالية.",
  },
  {
    id: 8,
    type: "multiple_choice",
    level: "B1",
    promptEn: "You ______ stop when the traffic light turns red.",
    promptAr: "يجب عليك ______ التوقف عندما تتحول إشارة المرور للأحمر.",
    options: ["might", "must", "could", "would"],
    correctIndex: 1,
    explanationAr: "نستخدم must للتعبير عن الإلزام القانوني أو الضرورة القاطعة.",
  },
  {
    id: 9,
    type: "multiple_choice",
    level: "B2",
    promptEn: "If I ______ more time, I would learn Spanish.",
    promptAr: "لو كان لدي وقت أطول، لتعلّمت اللغة الإسبانية.",
    options: ["have", "had", "will have", "would have"],
    correctIndex: 1,
    explanationAr: "الحالة الشرطية الثانية (Second Conditional): If + Past Simple (had), would + infinitive.",
  },
  {
    id: 10,
    type: "multiple_choice",
    level: "B2",
    promptEn: "The new bridge ______ by next December.",
    promptAr: "الجسر الجديد ______ بحلول ديسمبر القادم.",
    options: ["will build", "will be built", "is building", "builds"],
    correctIndex: 1,
    explanationAr: "صيغة مبني للمجهول في زمن المستقبل (Future Passive): will be built.",
  },
  {
    id: 11,
    type: "multiple_choice",
    level: "C1",
    promptEn: "What does the idiom 'once in a blue moon' mean?",
    promptAr: "ما معنى التعبير الاصطلاحي 'once in a blue moon'؟",
    options: ["Every night", "Very rarely", "Always", "On full moon only"],
    correctIndex: 1,
    explanationAr: "'Once in a blue moon' تعني نادراً جداً أو على فترات متباعدة للغاية.",
  },
  {
    id: 12,
    type: "multiple_choice",
    level: "C1",
    promptEn: "Had I known about the meeting, I ______ attended.",
    promptAr: "لو كنت على علم بالاجتماع، لكنت قد حضرت.",
    options: ["would have", "will have", "had", "would"],
    correctIndex: 0,
    explanationAr: "صيغة التقديم والتأخير (Inversion) للحالة الشرطية الثالثة: Had I known = If I had known ... would have attended.",
  },
];

export default function PlacementTestPage() {
  const { user, refreshUser } = useAuth();
  const [questions, setQuestions] = useState<PlacementQuestion[]>(defaultPlacementQuestions);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [resultData, setResultData] = useState<any>(null);

  const currentQ = questions[currentIndex];
  const totalQuestions = questions.length;
  const answeredCount = Object.keys(selectedAnswers).length;

  const handleSelect = (optionIndex: number) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [currentIndex]: optionIndex,
    }));
    playSoundEffect("click");
  };

  const calculateDeterminedLevel = (correctAnswers: number) => {
    if (correctAnswers <= 2) return "Pre-A1";
    if (correctAnswers <= 4) return "A1";
    if (correctAnswers <= 6) return "A2";
    if (correctAnswers <= 8) return "B1";
    if (correctAnswers <= 10) return "B2";
    return "C1";
  };

  const handleSubmitQuiz = async () => {
    setSubmitting(true);
    let correctCount = 0;

    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        correctCount++;
      }
    });

    const determinedLevel = calculateDeterminedLevel(correctCount);

    try {
      const res = await fetch("/api/quizzes/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quizId: 1, // Placement test ID
          answers: selectedAnswers,
          placementLevel: determinedLevel,
        }),
      });

      const data = await res.json();
      setResultData({
        ...data,
        correctCount,
        determinedLevel,
      });

      setQuizSubmitted(true);
      playSoundEffect("fanfare");

      try {
        confetti({
          particleCount: 120,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // Safe ignore
      }

      await refreshUser();
    } catch (err) {
      console.error("Submit placement test failed:", err);
      // Fallback local result
      setResultData({
        score: Math.round((correctCount / totalQuestions) * 100),
        correctCount,
        totalQuestions,
        determinedLevel,
      });
      setQuizSubmitted(true);
    } finally {
      setSubmitting(false);
    }
  };

  const handleRestart = () => {
    setSelectedAnswers({});
    setCurrentIndex(0);
    setQuizSubmitted(false);
    setResultData(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
            <Award className="w-3.5 h-3.5 text-indigo-400" />
            <span>اختبار تحديد المستوى المجاني الشامل (Placement Test)</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
            اكتشف مستواك الحقيقي في الإنجليزية بدقة
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
            12 سؤالاً متدرجة الصعوبة تبدأ من المبتدئ إلى المتقدم لتحديد مستواك طبقاً لمعايير CEFR الأوروبية وتخصيص مسارك التعليمي.
          </p>
        </div>

        {!quizSubmitted ? (
          <div className="space-y-6">
            {/* Progress Header */}
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-slate-300">
                  السؤال {currentIndex + 1} من {totalQuestions}
                </span>
                <LevelBadge level={currentQ.level} size="sm" />
              </div>

              <div className="flex-1 max-w-xs bg-slate-800 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-blue-500 to-indigo-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${((currentIndex + 1) / totalQuestions) * 100}%` }}
                ></div>
              </div>

              <span className="text-xs text-indigo-400 font-semibold">
                تمت إجابة {answeredCount}/{totalQuestions}
              </span>
            </div>

            {/* Question Card */}
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-400">نص السؤال:</span>
                  <AudioButton text={currentQ.promptEn} size="sm" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-white en-ltr leading-snug">
                  {currentQ.promptEn}
                </h3>
                <p className="text-sm text-indigo-300">{currentQ.promptAr}</p>
              </div>

              {/* Options */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                {currentQ.options.map((option, idx) => {
                  const isSelected = selectedAnswers[currentIndex] === idx;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelect(idx)}
                      className={`p-4 rounded-2xl flex items-center justify-between text-right transition-all duration-150 cursor-pointer ${
                        isSelected
                          ? "bg-indigo-600/30 text-white border-2 border-indigo-500 shadow-lg shadow-indigo-600/20"
                          : "bg-slate-800/70 hover:bg-slate-800 text-slate-200 border border-slate-700/60 hover:border-slate-600"
                      }`}
                    >
                      <span className="font-semibold text-sm sm:text-base en-ltr">{option}</span>
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                          isSelected
                            ? "bg-indigo-500 text-white"
                            : "bg-slate-700 text-slate-400"
                        }`}
                      >
                        {isSelected ? <Check className="w-3.5 h-3.5" /> : idx + 1}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Navigation controls */}
              <div className="pt-4 flex items-center justify-between border-t border-slate-800">
                <button
                  type="button"
                  disabled={currentIndex === 0}
                  onClick={() => setCurrentIndex((p) => p - 1)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 disabled:opacity-40 transition"
                >
                  <ArrowRight className="w-4 h-4" />
                  <span>السؤال السابق</span>
                </button>

                {currentIndex < totalQuestions - 1 ? (
                  <button
                    type="button"
                    onClick={() => setCurrentIndex((p) => p + 1)}
                    className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 transition shadow-lg shadow-indigo-600/20"
                  >
                    <span>السؤال التالي</span>
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleSubmitQuiz}
                    disabled={submitting}
                    className="px-8 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-2 transition shadow-lg shadow-emerald-600/20"
                  >
                    {submitting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <CheckCircle2 className="w-4 h-4" />
                    )}
                    <span>إنهاء الاختبار وعرض النتيجة</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ) : (
          /* Quiz Results View */
          <div className="space-y-8 animate-in fade-in duration-300">
            {/* Result Showcase Card */}
            <div className="p-8 rounded-3xl bg-gradient-to-br from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/40 shadow-2xl text-center space-y-6">
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 to-yellow-300 flex items-center justify-center text-slate-950 mx-auto shadow-2xl shadow-amber-500/30">
                <GraduationCap className="w-10 h-10" />
              </div>

              <div>
                <span className="text-xs font-semibold text-amber-300 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
                  نتيجة اختبار تحديد المستوى
                </span>
                <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2">
                  مستواك الموصى به:{" "}
                  <span className="bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
                    {resultData?.determinedLevel}
                  </span>
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 mt-2">
                  أجبت على {resultData?.correctCount} من أصل {totalQuestions} أسئلة بشكل صحيح (الدرجة: {resultData?.score || Math.round((resultData?.correctCount / totalQuestions) * 100)}%).
                </p>
              </div>

              {/* Level description */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 max-w-xl mx-auto text-xs text-slate-300 leading-relaxed text-right">
                <span className="font-bold text-white block mb-1">توصية الخطة التعليمية:</span>
                {resultData?.determinedLevel === "Pre-A1" && "ننصحك بالبدء من وحدة الحروف والأصوات الإنجليزية (Pre-A1) لإتقان النطق ومخارج الحروف وقواعد القراءة."}
                {resultData?.determinedLevel === "A1" && "لديك أساسيات جيدة، ننصحك بالبدء من مستوى A1 للتركيز على تكوين الجمل والمضارع البسيط والمحادثات اليومية."}
                {resultData?.determinedLevel === "A2" && "مستواك واعد! يمكنك البدء من مستوى A2 لتعلّم أزمنة الماضي والمستقبل ومحادثات السفر والمطارات."}
                {resultData?.determinedLevel === "B1" && "مستوى متوسط ممتاز! انطلق في مستوى B1 للتركيز على المضارع التام والأفعال الناقصة ومحادثات العمل."}
                {resultData?.determinedLevel === "B2" && "مستوى فوق المتوسط رائع! ركز على الجمل الشرطية المتقدمة والمبني للمجهول ومقابلات التوظيف."}
                {resultData?.determinedLevel === "C1" && "مستوى متقدم فائق! ركز على التعبيرات الاصطلاحية (Idioms) والطلاقة الأكاديمية الاحترافية."}
              </div>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <Link
                  href={resultData?.determinedLevel === "Pre-A1" ? "/alphabet" : "/grammar"}
                  className="w-full sm:w-auto px-8 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg transition flex items-center justify-center gap-2"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>انتقل إلى دروس مستواك الآن</span>
                </Link>

                <Link
                  href="/certificates"
                  className="w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 transition flex items-center justify-center gap-2"
                >
                  <Award className="w-4 h-4 text-emerald-400" />
                  <span>عرض الشهادة المكتسبة</span>
                </Link>

                <button
                  onClick={handleRestart}
                  className="w-full sm:w-auto px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white font-medium text-xs border border-slate-800 transition flex items-center justify-center gap-1.5"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>إعادة الاختبار</span>
                </button>
              </div>
            </div>

            {/* Detailed Explanations Breakdown */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-white">مراجعة الأسئلة والتفسيرات القواعدية:</h3>

              {questions.map((q, idx) => {
                const userChoice = selectedAnswers[idx];
                const isCorrect = userChoice === q.correctIndex;

                return (
                  <div
                    key={q.id}
                    className={`p-5 rounded-2xl border transition ${
                      isCorrect
                        ? "bg-emerald-950/20 border-emerald-500/30"
                        : "bg-rose-950/20 border-rose-500/30"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-400">سؤال {idx + 1}:</span>
                          <span className="text-sm font-bold text-white en-ltr">{q.promptEn}</span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{q.promptAr}</p>
                      </div>

                      <div className="shrink-0 flex items-center gap-1.5">
                        {isCorrect ? (
                          <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-400 bg-emerald-500/20 px-2.5 py-1 rounded-full border border-emerald-500/30">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>صحيح</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-400 bg-rose-500/20 px-2.5 py-1 rounded-full border border-rose-500/30">
                            <XCircle className="w-3.5 h-3.5" />
                            <span>غير صحيح</span>
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 text-xs space-y-1">
                      <p className="text-slate-300">
                        <strong>إجابتك:</strong>{" "}
                        <span className={isCorrect ? "text-emerald-300 font-semibold" : "text-rose-300 font-semibold"}>
                          {userChoice !== undefined ? q.options[userChoice] : "لم تجب"}
                        </span>
                      </p>
                      {!isCorrect && (
                        <p className="text-slate-300">
                          <strong>الإجابة الصحيحة:</strong>{" "}
                          <span className="text-emerald-300 font-bold">{q.options[q.correctIndex]}</span>
                        </p>
                      )}
                      <p className="text-indigo-300 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/80 mt-2">
                        💡 <strong>التفسير:</strong> {q.explanationAr}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
