"use client";

import React, { useState } from "react";
import { AudioButton } from "@/components/AudioButton";
import { playSoundEffect } from "@/lib/speech";
import confetti from "canvas-confetti";
import {
  Gamepad2,
  Sparkles,
  Award,
  RotateCcw,
  CheckCircle2,
  Zap,
  Shuffle,
} from "lucide-react";

interface WordPair {
  id: number;
  en: string;
  ar: string;
}

const wordPairsData: WordPair[] = [
  { id: 1, en: "Airport", ar: "مطار" },
  { id: 2, en: "Delicious", ar: "لذيذ" },
  { id: 3, en: "Opportunity", ar: "فرصة" },
  { id: 4, en: "Family", ar: "عائلة" },
  { id: 5, en: "Passport", ar: "جواز سفر" },
  { id: 6, en: "Achieve", ar: "يحقق" },
];

const sentencePuzzles = [
  {
    id: 1,
    target: "I drink hot coffee every morning",
    ar: "أنا أشرب القهوة الساخنة كل صباح",
    words: ["coffee", "I", "every", "hot", "drink", "morning"],
  },
  {
    id: 2,
    target: "She is a doctor in the hospital",
    ar: "هي طبيبة في المستشفى",
    words: ["a", "doctor", "the", "She", "is", "in", "hospital"],
  },
  {
    id: 3,
    target: "We arrived at the airport early",
    ar: "وصلنا إلى المطار مبكراً",
    words: ["arrived", "at", "We", "airport", "the", "early"],
  },
];

export default function GamesPage() {
  const [activeGame, setActiveGame] = useState<"matcher" | "sentence">("matcher");

  // Matcher State
  const [selectedEn, setSelectedEn] = useState<string | null>(null);
  const [selectedAr, setSelectedAr] = useState<string | null>(null);
  const [matchedIds, setMatchedIds] = useState<number[]>([]);
  const [matcherScore, setMatcherScore] = useState(0);

  // Sentence Puzzle State
  const [puzzleIndex, setPuzzleIndex] = useState(0);
  const [assembledWords, setAssembledWords] = useState<string[]>([]);
  const [puzzleFeedback, setPuzzleFeedback] = useState<"correct" | "wrong" | null>(null);
  const [puzzleScore, setPuzzleScore] = useState(0);

  const currentPuzzle = sentencePuzzles[puzzleIndex];

  // Matcher Click
  const handleEnClick = (word: string, id: number) => {
    setSelectedEn(word);
    if (selectedAr) {
      checkMatch(word, selectedAr, id);
    }
  };

  const handleArClick = (word: string, id: number) => {
    setSelectedAr(word);
    if (selectedEn) {
      checkMatch(selectedEn, word, id);
    }
  };

  const checkMatch = (en: string, ar: string, currentId: number) => {
    const pair = wordPairsData.find((p) => p.en === en && p.ar === ar);
    if (pair) {
      playSoundEffect("correct");
      setMatchedIds((prev) => [...prev, pair.id]);
      setMatcherScore((prev) => prev + 10);
      if (matchedIds.length + 1 === wordPairsData.length) {
        playSoundEffect("fanfare");
        try {
          confetti({ particleCount: 100, spread: 70 });
        } catch {}
      }
    } else {
      playSoundEffect("wrong");
    }
    setSelectedEn(null);
    setSelectedAr(null);
  };

  // Sentence Builder Click
  const handleAddWordToSentence = (word: string) => {
    setAssembledWords((prev) => [...prev, word]);
    playSoundEffect("click");
  };

  const handleRemoveWordFromSentence = (index: number) => {
    setAssembledWords((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleCheckSentence = () => {
    const fullSentence = assembledWords.join(" ");
    if (fullSentence.toLowerCase() === currentPuzzle.target.toLowerCase()) {
      playSoundEffect("correct");
      setPuzzleFeedback("correct");
      setPuzzleScore((prev) => prev + 25);

      setTimeout(() => {
        setPuzzleFeedback(null);
        setAssembledWords([]);
        if (puzzleIndex < sentencePuzzles.length - 1) {
          setPuzzleIndex((prev) => prev + 1);
        } else {
          playSoundEffect("fanfare");
          try {
            confetti({ particleCount: 100, spread: 70 });
          } catch {}
        }
      }, 1500);
    } else {
      playSoundEffect("wrong");
      setPuzzleFeedback("wrong");
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-pink-500/10 border border-pink-500/30 text-pink-300 text-xs font-semibold">
            <Gamepad2 className="w-3.5 h-3.5" />
            <span>الألعاب التعليمية التفاعلية</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
            تعلّم الإنجليزية من خلال الألعاب والتحديات
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            طريقة مسلية وسريعة لترسيخ المفردات وتراكيب الجمل في الذاكرة.
          </p>

          {/* Game Switcher Tabs */}
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={() => setActiveGame("matcher")}
              className={`px-5 py-2.5 rounded-2xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                activeGame === "matcher"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              <Shuffle className="w-4 h-4" />
              <span>لعبة مطابقة الكلمات والمعاني (Word Matcher)</span>
            </button>
            <button
              onClick={() => setActiveGame("sentence")}
              className={`px-5 py-2.5 rounded-2xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                activeGame === "sentence"
                  ? "bg-pink-600 text-white shadow-lg shadow-pink-600/30"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              <Zap className="w-4 h-4" />
              <span>لعبة بناء الجملة (Sentence Builder)</span>
            </button>
          </div>
        </div>

        {activeGame === "matcher" ? (
          /* Matcher Game */
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-lg font-bold text-white">طابق الكلمة الإنجليزية بمعناها العربي:</h3>
                <p className="text-xs text-slate-400">انقر على كلمة إنجليزية ثم انقر على الترجمة المطابقة لها.</p>
              </div>

              <div className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3.5 py-1.5 rounded-full border border-emerald-500/20">
                النقاط: {matcherScore} 🌟
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              {/* English Words Column */}
              <div className="space-y-3">
                <span className="text-xs font-semibold text-indigo-400">الكلمات الإنجليزية:</span>
                {wordPairsData.map((item) => {
                  const isMatched = matchedIds.includes(item.id);
                  const isSelected = selectedEn === item.en;

                  if (isMatched) {
                    return (
                      <div
                        key={item.id}
                        className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-400 text-center font-bold text-sm en-ltr opacity-60 line-through"
                      >
                        ✓ {item.en}
                      </div>
                    );
                  }

                  return (
                    <button
                      key={item.id}
                      onClick={() => handleEnClick(item.en, item.id)}
                      className={`w-full p-4 rounded-2xl font-bold text-sm en-ltr border transition text-center cursor-pointer ${
                        isSelected
                          ? "bg-indigo-600 text-white border-indigo-400 ring-2 ring-indigo-400"
                          : "bg-slate-950/80 hover:bg-slate-800 text-slate-200 border-slate-800"
                      }`}
                    >
                      {item.en}
                    </button>
                  );
                })}
              </div>

              {/* Arabic Meanings Column (Shuffled) */}
              <div className="space-y-3">
                <span className="text-xs font-semibold text-purple-400">المعاني العربية:</span>
                {[...wordPairsData]
                  .reverse()
                  .map((item) => {
                    const isMatched = matchedIds.includes(item.id);
                    const isSelected = selectedAr === item.ar;

                    if (isMatched) {
                      return (
                        <div
                          key={item.id}
                          className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 text-emerald-400 text-center font-bold text-sm opacity-60 line-through"
                        >
                          ✓ {item.ar}
                        </div>
                      );
                    }

                    return (
                      <button
                        key={item.id}
                        onClick={() => handleArClick(item.ar, item.id)}
                        className={`w-full p-4 rounded-2xl font-bold text-sm border transition text-center cursor-pointer ${
                          isSelected
                            ? "bg-purple-600 text-white border-purple-400 ring-2 ring-purple-400"
                            : "bg-slate-950/80 hover:bg-slate-800 text-slate-200 border-slate-800"
                        }`}
                      >
                        {item.ar}
                      </button>
                    );
                  })}
              </div>
            </div>

            {matchedIds.length === wordPairsData.length && (
              <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-2 animate-in fade-in">
                <h4 className="text-xl font-bold text-emerald-300">🎉 رائع جداً! طابقت جميع الكلمات بنجاح!</h4>
                <button
                  onClick={() => {
                    setMatchedIds([]);
                    setMatcherScore(0);
                  }}
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs inline-flex items-center gap-1.5 transition"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>العب مجدداً</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Sentence Builder Game */
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <span className="text-xs font-bold text-indigo-400">
                  الجملة {puzzleIndex + 1} من {sentencePuzzles.length}
                </span>
                <h3 className="text-lg font-bold text-white mt-1">رتّب الكلمات لتكوين جملة إنجليزية صحيحة:</h3>
                <p className="text-xs text-amber-300 mt-0.5">المعنى المطلوب: «{currentPuzzle.ar}»</p>
              </div>

              <div className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-3.5 py-1.5 rounded-full border border-emerald-500/20">
                النقاط: {puzzleScore} 🌟
              </div>
            </div>

            {/* Assembled Sentence Drop Area */}
            <div className="p-6 rounded-2xl bg-slate-950/90 border-2 border-dashed border-slate-700 min-h-[90px] flex flex-wrap items-center gap-2">
              {assembledWords.length === 0 ? (
                <span className="text-xs text-slate-500">انقر على الكلمات بالأسفل لإضافتها هنا بالترتيب الصحيح...</span>
              ) : (
                assembledWords.map((word, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleRemoveWordFromSentence(idx)}
                    title="انقر للحذف"
                    className="px-3.5 py-2 rounded-xl bg-indigo-600 text-white font-bold text-sm en-ltr hover:bg-rose-600 transition shadow cursor-pointer"
                  >
                    {word} ✕
                  </button>
                ))
              )}
            </div>

            {/* Available Word Chips */}
            <div>
              <p className="text-xs text-slate-400 mb-2">الكلمات المتاحة:</p>
              <div className="flex flex-wrap gap-2">
                {currentPuzzle.words.map((word, idx) => {
                  const usedCountInAssembly = assembledWords.filter((w) => w === word).length;
                  const totalCountInPuzzle = currentPuzzle.words.filter((w) => w === word).length;
                  const isUsed = usedCountInAssembly >= totalCountInPuzzle;

                  return (
                    <button
                      key={idx}
                      disabled={isUsed}
                      onClick={() => handleAddWordToSentence(word)}
                      className={`px-4 py-2.5 rounded-xl font-bold text-sm en-ltr border transition cursor-pointer ${
                        isUsed
                          ? "opacity-30 bg-slate-800 border-slate-700 cursor-not-allowed"
                          : "bg-slate-800 hover:bg-indigo-600 text-white border-slate-700 hover:border-indigo-500 active:scale-95"
                      }`}
                    >
                      {word}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setAssembledWords([])}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
              >
                مسح الترتيب
              </button>

              <button
                onClick={handleCheckSentence}
                disabled={assembledWords.length === 0}
                className="px-8 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg transition"
              >
                تحقق من صحة الجملة ✓
              </button>
            </div>

            {puzzleFeedback && (
              <div
                className={`p-3.5 rounded-2xl text-xs font-bold animate-in fade-in duration-200 ${
                  puzzleFeedback === "correct"
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                    : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                }`}
              >
                {puzzleFeedback === "correct"
                  ? "🎉 إجابة صحيحة وممتازة! ترتيب الجملة سليم قواعدياً."
                  : "❌ ترتيب غير صحيح. حاول إعادة ترتيب الكلمات."}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
