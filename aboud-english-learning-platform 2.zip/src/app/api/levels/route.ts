import { NextResponse } from "next/server";
import { db } from "@/db";
import { levels, units, lessons } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { seedDatabase } from "@/db/seed";

export async function GET() {
  try {
    await seedDatabase();

    const allLevels = await db.select().from(levels).orderBy(asc(levels.orderIndex));
    const allUnits = await db.select().from(units).orderBy(asc(units.orderIndex));
    const allLessons = await db.select().from(lessons).orderBy(asc(lessons.orderIndex));

    const enrichedLevels = allLevels.map((lvl) => {
      const lvlUnits = allUnits.filter((u) => u.levelCode === lvl.code);
      const lvlLessons = allLessons.filter((l) => l.levelCode === lvl.code);
      return {
        ...lvl,
        unitsCount: lvlUnits.length,
        lessonsCount: lvlLessons.length,
        units: lvlUnits.map((u) => ({
          ...u,
          lessons: lvlLessons.filter((l) => l.unitId === u.id),
        })),
      };
    });

    return NextResponse.json({ levels: enrichedLevels });
  } catch (error) {
    console.error("Levels fetch error:", error);
    return NextResponse.json({ error: "فشل تحميل المستويات" }, { status: 500 });
  }
}
