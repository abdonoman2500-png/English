import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, lessons, vocabulary, quizzes, quizAttempts, certificates, contactMessages } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || (currentUser.role !== "admin" && currentUser.role !== "teacher")) {
      return NextResponse.json({ error: "غير مصرح لك بالوصول للإحصائيات" }, { status: 403 });
    }

    const allUsers = await db.select().from(users);
    const allLessons = await db.select().from(lessons);
    const allVocab = await db.select().from(vocabulary);
    const allQuizzes = await db.select().from(quizzes);
    const allAttempts = await db.select().from(quizAttempts);
    const allCerts = await db.select().from(certificates);
    const allMessages = await db.select().from(contactMessages);

    const students = allUsers.filter((u) => u.role === "student");
    const teachers = allUsers.filter((u) => u.role === "teacher");
    const passedAttempts = allAttempts.filter((a) => a.passed);

    const stats = {
      totalUsers: allUsers.length,
      totalStudents: students.length,
      totalTeachers: teachers.length,
      totalLessons: allLessons.length,
      totalVocabulary: allVocab.length,
      totalQuizzes: allQuizzes.length,
      totalQuizAttempts: allAttempts.length,
      passRate: allAttempts.length > 0 ? Math.round((passedAttempts.length / allAttempts.length) * 100) : 0,
      totalCertificatesIssued: allCerts.length,
      unreadMessages: allMessages.filter((m) => m.status === "unread").length,
      recentUsers: allUsers.slice(-5).reverse(),
      recentMessages: allMessages.slice(-5).reverse(),
    };

    return NextResponse.json({ stats });
  } catch (error) {
    console.error("Admin stats error:", error);
    return NextResponse.json({ error: "فشل تحميل إحصائيات الإدارة" }, { status: 500 });
  }
}
