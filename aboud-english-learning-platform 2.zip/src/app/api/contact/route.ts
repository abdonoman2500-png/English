import { NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const { name, email, subject, message } = await request.json();

    if (!name || !email || !subject || !message) {
      return NextResponse.json({ error: "جميع الحقول مطلوبة" }, { status: 400 });
    }

    const [newMessage] = await db
      .insert(contactMessages)
      .values({
        name: name.trim(),
        email: email.trim(),
        subject: subject.trim(),
        message: message.trim(),
      })
      .returning();

    return NextResponse.json({
      success: true,
      message: "تم إرسال رسالتك بنجاح! سنرد عليك في أقرب وقت.",
      contactId: newMessage.id,
    });
  } catch (error) {
    console.error("Contact error:", error);
    return NextResponse.json({ error: "فشل إرسال الرسالة" }, { status: 500 });
  }
}
