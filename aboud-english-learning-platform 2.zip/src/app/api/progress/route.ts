import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, userProgress, quizAttempts, userFavorites, lessons, certificates } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "غير مسجل الدخول" }, { status: 401 });
    }

    const [userRecord] = await db.select().from(users).where(eq(users.id, currentUser.id)).limit(1);

    const completedLessons = await db
      .select({
        id: userProgress.id,
        completedAt: userProgress.completedAt,
        lessonId: lessons.id,
        titleAr: lessons.titleAr,
        titleEn: lessons.titleEn,
        levelCode: lessons.levelCode,
        category: lessons.category,
      })
      .from(userProgress)
      .innerJoin(lessons, eq(userProgress.lessonId, lessons.id))
      .where(eq(userProgress.userId, currentUser.id))
      .orderBy(desc(userProgress.completedAt));

    const attempts = await db
      .select()
      .from(quizAttempts)
      .where(eq(quizAttempts.userId, currentUser.id))
      .orderBy(desc(quizAttempts.completedAt))
      .limit(10);

    const favorites = await db
      .select()
      .from(userFavorites)
      .where(eq(userFavorites.userId, currentUser.id));

    const userCerts = await db
      .select()
      .from(certificates)
      .where(eq(certificates.userId, currentUser.id))
      .orderBy(desc(certificates.issuedAt));

    const totalLessons = await db.select({ id: lessons.id }).from(lessons);

    const stats = {
      user: {
        id: userRecord.id,
        name: userRecord.name,
        email: userRecord.email,
        role: userRecord.role,
        currentLevel: userRecord.currentLevel,
        xp: userRecord.xp,
        streakDays: userRecord.streakDays,
      },
      completedLessonsCount: completedLessons.length,
      totalLessonsCount: totalLessons.length,
      progressPercentage: totalLessons.length > 0 ? Math.round((completedLessons.length / totalLessons.length) * 100) : 0,
      savedWordsCount: favorites.length,
      masteredWordsCount: favorites.filter((f) => f.mastered).length,
      quizzesTaken: attempts.length,
      recentLessons: completedLessons.slice(0, 5),
      recentQuizAttempts: attempts,
      certificates: userCerts,
    };

    return NextResponse.json(stats);
  } catch (error) {
    console.error("Progress fetch error:", error);
    return NextResponse.json({ error: "فشل تحميل بيانات التقدم" }, { status: 500 });
  }
}
