import { NextResponse } from "next/server";
import { db } from "@/db";
import { certificates, users } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const certNumber = searchParams.get("code");

    // If searching by certificate number (public verification)
    if (certNumber) {
      const [cert] = await db
        .select()
        .from(certificates)
        .where(eq(certificates.certificateNumber, certNumber))
        .limit(1);

      if (!cert) {
        return NextResponse.json({ error: "الشهادة غير موجودة أو الرقم غير صحيح" }, { status: 404 });
      }

      return NextResponse.json({ certificate: cert });
    }

    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ certificates: [] });
    }

    const userCerts = await db
      .select()
      .from(certificates)
      .where(eq(certificates.userId, currentUser.id))
      .orderBy(desc(certificates.issuedAt));

    return NextResponse.json({ certificates: userCerts });
  } catch (error) {
    console.error("Certificates error:", error);
    return NextResponse.json({ error: "فشل تحميل الشهادات" }, { status: 500 });
  }
}

// Issue completion certificate for level
export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "يرجى تسجيل الدخول للحصول على الشهادة" }, { status: 401 });
    }

    const { levelCode, score } = await request.json();

    const certNumber = `ABOUD-${Date.now().toString().slice(-6)}-${levelCode || "A1"}`;

    const [newCert] = await db
      .insert(certificates)
      .values({
        certificateNumber: certNumber,
        userId: currentUser.id,
        levelCode: levelCode || "A1",
        studentName: currentUser.name,
        score: Number(score) || 90,
      })
      .returning();

    return NextResponse.json({ success: true, certificate: newCert });
  } catch (error) {
    console.error("Issue certificate error:", error);
    return NextResponse.json({ error: "فشل إصدار الشهادة" }, { status: 500 });
  }
}
