import { NextResponse } from "next/server";
import { db } from "@/db";
import { lessons, userProgress, users } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const lessonId = parseInt(id, 10);

    if (isNaN(lessonId)) {
      return NextResponse.json({ error: "معرف الدرس غير صالح" }, status(400));
    }

    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, lessonId)).limit(1);

    if (!lesson) {
      return NextResponse.json({ error: "الدرس غير موجود" }, { status: 404 });
    }

    const currentUser = await getCurrentUser();
    let isCompleted = false;

    if (currentUser) {
      const [progress] = await db
        .select()
        .from(userProgress)
        .where(and(eq(userProgress.userId, currentUser.id), eq(userProgress.lessonId, lessonId)))
        .limit(1);
      isCompleted = !!progress;
    }

    return NextResponse.json({ lesson: { ...lesson, isCompleted } });
  } catch (error) {
    console.error("Single lesson fetch error:", error);
    return NextResponse.json({ error: "فشل تحميل الدرس" }, { status: 500 });
  }
}

// Mark lesson as completed
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json({ error: "يرجى تسجيل الدخول لحفظ تقدمك" }, { status: 401 });
    }

    const { id } = await params;
    const lessonId = parseInt(id, 10);

    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, lessonId)).limit(1);
    if (!lesson) {
      return NextResponse.json({ error: "الدرس غير موجود" }, { status: 404 });
    }

    // Check if already completed
    const [existingProgress] = await db
      .select()
      .from(userProgress)
      .where(and(eq(userProgress.userId, currentUser.id), eq(userProgress.lessonId, lessonId)))
      .limit(1);

    if (!existingProgress) {
      await db.insert(userProgress).values({
        userId: currentUser.id,
        lessonId: lessonId,
        status: "completed",
      });

      // Award XP
      const addedXp = lesson.xpReward || 25;
      await db
        .update(users)
        .set({
          xp: currentUser.xp + addedXp,
          lastActiveDate: new Date(),
        })
        .where(eq(users.id, currentUser.id));

      return NextResponse.json({
        success: true,
        message: `أحسنت! أكملت الدرس وحصلت على ${addedXp} نقطة XP`,
        xpGained: addedXp,
      });
    }

    return NextResponse.json({ success: true, message: "تم إكمال هذا الدرس مسبقاً" });
  } catch (error) {
    console.error("Complete lesson error:", error);
    return NextResponse.json({ error: "فشل حفظ التقدم" }, { status: 500 });
  }
}

function status(code: number) {
  return { status: code };
}
