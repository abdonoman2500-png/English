import { NextResponse } from "next/server";
import { db } from "@/db";
import { lessons, userProgress, users } from "@/db/schema";
import { eq, and, asc } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const levelCode = searchParams.get("level");
    const category = searchParams.get("category");

    let query = db.select().from(lessons);

    const allLessons = await query.orderBy(asc(lessons.orderIndex));

    let filtered = allLessons;
    if (levelCode) {
      filtered = filtered.filter((l) => l.levelCode === levelCode);
    }
    if (category) {
      filtered = filtered.filter((l) => l.category === category);
    }

    const currentUser = await getCurrentUser();
    let completedLessonIds = new Set<number>();

    if (currentUser) {
      const progressRecords = await db
        .select({ lessonId: userProgress.lessonId })
        .from(userProgress)
        .where(eq(userProgress.userId, currentUser.id));
      completedLessonIds = new Set(progressRecords.map((p) => p.lessonId));
    }

    const lessonsWithStatus = filtered.map((lesson) => ({
      ...lesson,
      isCompleted: completedLessonIds.has(lesson.id),
    }));

    return NextResponse.json({ lessons: lessonsWithStatus });
  } catch (error) {
    console.error("Lessons API error:", error);
    return NextResponse.json({ error: "فشل تحميل الدروس" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const currentUser = await getCurrentUser();
    if (!currentUser || (currentUser.role !== "admin" && currentUser.role !== "teacher")) {
      return NextResponse.json({ error: "غير مصرح لك بإضافة دروس" }, { status: 403 });
    }

    const body = await request.json();
    const { unitId, levelCode, category, titleAr, titleEn, descriptionAr, contentJson, orderIndex, xpReward, durationMinutes } = body;

    if (!levelCode || !category || !titleAr || !titleEn || !contentJson) {
      return NextResponse.json({ error: "البيانات الأساسية للدرس مطلوبة" }, { status: 400 });
    }

    const [newLesson] = await db
      .insert(lessons)
      .values({
        unitId: unitId ? Number(unitId) : null,
        levelCode,
        category,
        titleAr,
        titleEn,
        descriptionAr: descriptionAr || "",
        contentJson: typeof contentJson === "string" ? contentJson : JSON.stringify(contentJson),
        orderIndex: Number(orderIndex) || 1,
        xpReward: Number(xpReward) || 25,
        durationMinutes: Number(durationMinutes) || 10,
        isPublished: true,
      })
      .returning();

    return NextResponse.json({ success: true, lesson: newLesson });
  } catch (error) {
    console.error("Create lesson error:", error);
    return NextResponse.json({ error: "فشل إنشاء الدرس" }, { status: 500 });
  }
}
