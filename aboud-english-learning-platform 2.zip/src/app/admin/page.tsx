"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { LevelBadge } from "@/components/LevelBadge";
import {
  ShieldAlert,
  Users,
  BookOpen,
  Bookmark,
  Gamepad2,
  Award,
  Plus,
  Trash2,
  Edit,
  CheckCircle2,
  Loader2,
  MessageSquare,
  Sparkles,
} from "lucide-react";

export default function AdminPage() {
  const { user, quickLogin } = useAuth();
  const [activeTab, setActiveTab] = useState<"overview" | "lessons" | "vocab" | "users">("overview");
  const [stats, setStats] = useState<any>(null);
  const [loadingStats, setLoadingStats] = useState(true);

  // Users tab state
  const [userList, setUserList] = useState<any[]>([]);
  const [loadingUsers, setLoadingUsers] = useState(false);

  // Lesson Create Form state
  const [newLesson, setNewLesson] = useState({
    levelCode: "A1",
    category: "grammar",
    titleAr: "",
    titleEn: "",
    descriptionAr: "",
    contentSummary: "",
    xpReward: 25,
    durationMinutes: 10,
  });
  const [lessonSubmitting, setLessonSubmitting] = useState(false);
  const [lessonSuccessMsg, setLessonSuccessMsg] = useState("");

  // Vocabulary Create Form state
  const [newVocab, setNewVocab] = useState({
    word: "",
    phonetic: "",
    partOfSpeech: "noun",
    translationAr: "",
    levelCode: "A1",
    category: "basics",
    exampleEn: "",
    exampleAr: "",
  });
  const [vocabSubmitting, setVocabSubmitting] = useState(false);
  const [vocabSuccessMsg, setVocabSuccessMsg] = useState("");

  useEffect(() => {
    async function loadStats() {
      try {
        const res = await fetch("/api/admin/stats");
        const data = await res.json();
        if (data.stats) {
          setStats(data.stats);
        }
      } catch (err) {
        console.error("Load stats failed", err);
      } finally {
        setLoadingStats(false);
      }
    }

    if (user?.role === "admin" || user?.role === "teacher") {
      loadStats();
    }
  }, [user]);

  const loadUsers = async () => {
    setLoadingUsers(true);
    try {
      const res = await fetch("/api/admin/users");
      const data = await res.json();
      if (data.users) {
        setUserList(data.users);
      }
    } catch (err) {
      console.error("Load users failed", err);
    } finally {
      setLoadingUsers(false);
    }
  };

  const handleUpdateUserRole = async (userId: number, role: string, currentLevel?: string) => {
    try {
      const res = await fetch("/api/admin/users", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, role, currentLevel }),
      });
      if (res.ok) {
        loadUsers();
      }
    } catch (err) {
      console.error("Update user error", err);
    }
  };

  const handleCreateLesson = async (e: React.FormEvent) => {
    e.preventDefault();
    setLessonSubmitting(true);
    setLessonSuccessMsg("");

    try {
      const contentJson = JSON.stringify({
        summary: newLesson.contentSummary,
        sections: [
          {
            heading: "شرح الدرس الأساسي",
            text: newLesson.descriptionAr,
          },
        ],
      });

      const res = await fetch("/api/lessons", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...newLesson,
          contentJson,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setLessonSuccessMsg("تمت إضافة الدرس بنجاح ونشره للطلاب!");
        setNewLesson({
          levelCode: "A1",
          category: "grammar",
          titleAr: "",
          titleEn: "",
          descriptionAr: "",
          contentSummary: "",
          xpReward: 25,
          durationMinutes: 10,
        });
      }
    } catch {
      alert("فشل إضافة الدرس");
    } finally {
      setLessonSubmitting(false);
    }
  };

  const handleCreateVocab = async (e: React.FormEvent) => {
    e.preventDefault();
    setVocabSubmitting(true);
    setVocabSuccessMsg("");

    try {
      const res = await fetch("/api/vocabulary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newVocab),
      });

      if (res.ok) {
        setVocabSuccessMsg("تمت إضافة الكلمة إلى القاموس بنجاح!");
        setNewVocab({
          word: "",
          phonetic: "",
          partOfSpeech: "noun",
          translationAr: "",
          levelCode: "A1",
          category: "basics",
          exampleEn: "",
          exampleAr: "",
        });
      }
    } catch {
      alert("فشل إضافة الكلمة");
    } finally {
      setVocabSubmitting(false);
    }
  };

  // If not logged in as Admin / Teacher, show Switcher Banner
  if (!user || (user.role !== "admin" && user.role !== "teacher")) {
    return (
      <div className="min-h-[75vh] flex items-center justify-center px-4 py-12">
        <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 text-center space-y-4 max-w-md">
          <ShieldAlert className="w-12 h-12 text-amber-400 mx-auto" />
          <h2 className="text-2xl font-bold text-white">لوحة الإدارة والتحكم</h2>
          <p className="text-xs text-slate-300">
            هذه الصفحة مخصصة لمدير المنصة والمعلمين لإدارة الدروس والمفردات والطلاب.
          </p>
          <div className="pt-2">
            <button
              onClick={() => quickLogin("admin")}
              className="w-full py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow-lg transition"
            >
              تسجيل الدخول كمدير المنصة (الأستاذ عبود)
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-2">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>لوحة الإدارة الأكاديمية والتحكم</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
              لوحة تحكم المدير والمعلم
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              مرحباً {user.name} ({user.role === "admin" ? "المدير العام" : "معلم"})
            </p>
          </div>

          {/* Tab Selector */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setActiveTab("overview")}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeTab === "overview"
                  ? "bg-amber-600 text-white"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              الإحصائيات العامة
            </button>
            <button
              onClick={() => setActiveTab("lessons")}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeTab === "lessons"
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              إضافة درس جديد
            </button>
            <button
              onClick={() => setActiveTab("vocab")}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeTab === "vocab"
                  ? "bg-purple-600 text-white"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              إضافة مفردات للقاموس
            </button>
            <button
              onClick={() => {
                setActiveTab("users");
                loadUsers();
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                activeTab === "users"
                  ? "bg-blue-600 text-white"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              إدارة المستخدمين
            </button>
          </div>
        </div>

        {/* Tab 1: Overview Analytics */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
                <p className="text-2xl font-bold text-white">{stats?.totalStudents || 0}</p>
                <p className="text-xs text-slate-400">إجمالي الطلاب المسجلين</p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
                <p className="text-2xl font-bold text-indigo-400">{stats?.totalLessons || 0}</p>
                <p className="text-xs text-slate-400">إجمالي الدروس المنشورة</p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
                <p className="text-2xl font-bold text-purple-400">{stats?.totalVocabulary || 0}</p>
                <p className="text-xs text-slate-400">كلمات القاموس</p>
              </div>

              <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800">
                <p className="text-2xl font-bold text-emerald-400">{stats?.totalCertificatesIssued || 0}</p>
                <p className="text-xs text-slate-400">شهادات تم إصدارها</p>
              </div>
            </div>

            {/* Recent Messages & Activity */}
            {stats?.recentMessages && stats.recentMessages.length > 0 && (
              <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-indigo-400" />
                  <span>رسائل واستفسارات الطلاب الواردة:</span>
                </h3>

                <div className="space-y-2">
                  {stats.recentMessages.map((msg: any) => (
                    <div
                      key={msg.id}
                      className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1 text-xs"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">
                          {msg.name} ({msg.email})
                        </span>
                        <span className="text-slate-500 text-[10px]">
                          {new Date(msg.createdAt).toLocaleDateString("ar-EG")}
                        </span>
                      </div>
                      <p className="text-indigo-300 font-semibold">{msg.subject}</p>
                      <p className="text-slate-300 leading-relaxed">{msg.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Create Lesson */}
        {activeTab === "lessons" && (
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl max-w-3xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Plus className="w-6 h-6 text-indigo-400" />
              <span>إضافة درس تعليمي جديد</span>
            </h2>

            {lessonSuccessMsg && (
              <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs">
                {lessonSuccessMsg}
              </div>
            )}

            <form onSubmit={handleCreateLesson} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">المستوى التعليمي (CEFR)</label>
                  <select
                    value={newLesson.levelCode}
                    onChange={(e) => setNewLesson({ ...newLesson, levelCode: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  >
                    <option value="Pre-A1">Pre-A1 (التمهيدي)</option>
                    <option value="A1">A1 (المبتدئ)</option>
                    <option value="A2">A2 (فوق المبتدئ)</option>
                    <option value="B1">B1 (المتوسط)</option>
                    <option value="B2">B2 (فوق المتوسط)</option>
                    <option value="C1">C1 (المتقدم)</option>
                    <option value="C2">C2 (المتقن)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">قسم الدرس</label>
                  <select
                    value={newLesson.category}
                    onChange={(e) => setNewLesson({ ...newLesson, category: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  >
                    <option value="grammar">قواعد (Grammar)</option>
                    <option value="alphabet">حروف وأصوات (Alphabet)</option>
                    <option value="vocabulary">مفردات (Vocabulary)</option>
                    <option value="conversation">محادثات (Conversation)</option>
                    <option value="listening">استماع (Listening)</option>
                    <option value="reading">قراءة (Reading)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">عنوان الدرس بالعربية</label>
                  <input
                    type="text"
                    required
                    value={newLesson.titleAr}
                    onChange={(e) => setNewLesson({ ...newLesson, titleAr: e.target.value })}
                    placeholder="مثال: زمن الماضي المستمر"
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">عنوان الدرس بالإنجليزية</label>
                  <input
                    type="text"
                    required
                    value={newLesson.titleEn}
                    onChange={(e) => setNewLesson({ ...newLesson, titleEn: e.target.value })}
                    placeholder="Past Continuous Tense"
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white en-ltr"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">ملخص الدرس التمهيدي</label>
                <input
                  type="text"
                  required
                  value={newLesson.contentSummary}
                  onChange={(e) => setNewLesson({ ...newLesson, contentSummary: e.target.value })}
                  placeholder="موجز سريع لما يتعلمه الطالب في هذا الدرس..."
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">شرح الدرس والقاعدة بالتفصيل</label>
                <textarea
                  rows={4}
                  required
                  value={newLesson.descriptionAr}
                  onChange={(e) => setNewLesson({ ...newLesson, descriptionAr: e.target.value })}
                  placeholder="اكتب شرح القاعدة، الأمثلة، والتنبيهات..."
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={lessonSubmitting}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg transition"
              >
                {lessonSubmitting ? "جارٍ الحفظ..." : "نشر الدرس الآن"}
              </button>
            </form>
          </div>
        )}

        {/* Tab 3: Create Vocabulary */}
        {activeTab === "vocab" && (
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl max-w-3xl mx-auto space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Bookmark className="w-6 h-6 text-purple-400" />
              <span>إضافة كلمة جديدة للقاموس</span>
            </h2>

            {vocabSuccessMsg && (
              <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs">
                {vocabSuccessMsg}
              </div>
            )}

            <form onSubmit={handleCreateVocab} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">الكلمة بالإنجليزية (Word)</label>
                  <input
                    type="text"
                    required
                    value={newVocab.word}
                    onChange={(e) => setNewVocab({ ...newVocab, word: e.target.value })}
                    placeholder="Adventure"
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white en-ltr"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">الرمز الصوتي (IPA)</label>
                  <input
                    type="text"
                    value={newVocab.phonetic}
                    onChange={(e) => setNewVocab({ ...newVocab, phonetic: e.target.value })}
                    placeholder="/ədˈven.tʃər/"
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white en-ltr"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">الترجمة بالعربية</label>
                  <input
                    type="text"
                    required
                    value={newVocab.translationAr}
                    onChange={(e) => setNewVocab({ ...newVocab, translationAr: e.target.value })}
                    placeholder="مغامرة"
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">المستوى (CEFR)</label>
                  <select
                    value={newVocab.levelCode}
                    onChange={(e) => setNewVocab({ ...newVocab, levelCode: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  >
                    <option value="Pre-A1">Pre-A1</option>
                    <option value="A1">A1</option>
                    <option value="A2">A2</option>
                    <option value="B1">B1</option>
                    <option value="B2">B2</option>
                    <option value="C1">C1</option>
                    <option value="C2">C2</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">الموضوع (Category)</label>
                  <select
                    value={newVocab.category}
                    onChange={(e) => setNewVocab({ ...newVocab, category: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  >
                    <option value="basics">الأساسيات والتحيات</option>
                    <option value="family">العائلة</option>
                    <option value="food">الطعام</option>
                    <option value="travel">السفر</option>
                    <option value="business">العمل</option>
                    <option value="idioms">Idioms</option>
                    <option value="academic">أكاديمي</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1 font-semibold">نوع الكلمة (Part of Speech)</label>
                  <select
                    value={newVocab.partOfSpeech}
                    onChange={(e) => setNewVocab({ ...newVocab, partOfSpeech: e.target.value })}
                    className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                  >
                    <option value="noun">اسم (Noun)</option>
                    <option value="verb">فعل (Verb)</option>
                    <option value="adjective">صفة (Adjective)</option>
                    <option value="adverb">ظرف (Adverb)</option>
                    <option value="idiom">تعبير (Idiom)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">مثال جملة بالإنجليزية</label>
                <input
                  type="text"
                  value={newVocab.exampleEn}
                  onChange={(e) => setNewVocab({ ...newVocab, exampleEn: e.target.value })}
                  placeholder="Life is an amazing adventure."
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white en-ltr"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">ترجمة المثال بالعربية</label>
                <input
                  type="text"
                  value={newVocab.exampleAr}
                  onChange={(e) => setNewVocab({ ...newVocab, exampleAr: e.target.value })}
                  placeholder="الحياة مغامرة مذهلة."
                  className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white"
                />
              </div>

              <button
                type="submit"
                disabled={vocabSubmitting}
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg transition"
              >
                {vocabSubmitting ? "جارٍ الحفظ..." : "إضافة الكلمة للقاموس"}
              </button>
            </form>
          </div>
        )}

        {/* Tab 4: Users Management */}
        {activeTab === "users" && (
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
            <h2 className="text-2xl font-bold text-white flex items-center gap-2">
              <Users className="w-6 h-6 text-blue-400" />
              <span>إدارة حسابات الطلاب والمعلمين</span>
            </h2>

            {loadingUsers ? (
              <div className="py-12 text-center text-xs text-slate-400">جارٍ جلب المستخدمين...</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="p-3">الاسم</th>
                      <th className="p-3">البريد الإلكتروني</th>
                      <th className="p-3">المستوى</th>
                      <th className="p-3">النقاط (XP)</th>
                      <th className="p-3">الصلاحية (Role)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {userList.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-800/40">
                        <td className="p-3 font-semibold text-white">{u.name}</td>
                        <td className="p-3 text-slate-400 en-ltr">{u.email}</td>
                        <td className="p-3">
                          <LevelBadge level={u.currentLevel} size="sm" />
                        </td>
                        <td className="p-3 text-indigo-300 font-bold">{u.xp} XP</td>
                        <td className="p-3">
                          <select
                            value={u.role}
                            onChange={(e) => handleUpdateUserRole(u.id, e.target.value)}
                            className="p-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white"
                          >
                            <option value="student">طالب (Student)</option>
                            <option value="teacher">معلم (Teacher)</option>
                            <option value="admin">مدير (Admin)</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
