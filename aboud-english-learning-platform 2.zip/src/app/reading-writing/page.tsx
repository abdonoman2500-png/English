"use client";

import React, { useState } from "react";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import { playSoundEffect } from "@/lib/speech";
import {
  FileText,
  Sparkles,
  BookOpen,
  PenTool,
  CheckCircle2,
  HelpCircle,
  Lightbulb,
  Send,
  Volume2,
} from "lucide-react";

interface StoryItem {
  id: string;
  level: string;
  titleAr: string;
  titleEn: string;
  contentEn: string;
  contentAr: string;
  questions: Array<{
    qEn: string;
    qAr: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  }>;
}

const stories: StoryItem[] = [
  {
    id: "story-1",
    level: "A1",
    titleAr: "يوم في حياة طالب (A Day in the Life of a Student)",
    titleEn: "A Day in the Life of a Student",
    contentEn:
      "My name is Omar. I wake up at seven o'clock every morning. First, I wash my face and brush my teeth. Then, I eat breakfast with my family. I usually have eggs and bread with warm tea. At eight o'clock, I walk to my English school. I love learning new vocabulary and talking with my classmates. In the evening, I do my homework and read an English short story before going to bed.",
    contentAr:
      "اسمي عمر. أستيقظ في الساعة السابعة كل صباح. أولاً، أغسل وجهي وأنظف أسناني. بعد ذلك، أتناول الإفطار مع عائلتي. عادةً ما أتناول البيض والخبز مع الشاي الدافئ. في الساعة الثامنة، أسير إلى مدرستي لتعليم الإنجليزية. أحب تعلم مفردات جديدة والتحدث مع زملائي. في المساء، أحل واجباتي وأقرأ قصة إنجليزية قصيرة قبل النوم.",
    questions: [
      {
        qEn: "What time does Omar wake up?",
        qAr: "في أي ساعة يستيقظ عمر؟",
        options: ["At six o'clock", "At seven o'clock", "At eight o'clock"],
        correctIndex: 1,
        explanation: "النص يذكر بوضوح: 'I wake up at seven o'clock every morning.'",
      },
      {
        qEn: "How does Omar travel to his English school?",
        qAr: "كيف يذهب عمر إلى مدرسة الإنجليزية؟",
        options: ["By bus", "By car", "He walks"],
        correctIndex: 2,
        explanation: "النص يذكر: 'I walk to my English school.' أي أنه يسير على الأقدام.",
      },
    ],
  },
  {
    id: "story-2",
    level: "A2",
    titleAr: "رحلة لا تُنسى إلى الجبال (An Unforgettable Mountain Trip)",
    titleEn: "An Unforgettable Mountain Trip",
    contentEn:
      "Last summer, my friends and I traveled to the beautiful green mountains. The weather was cool and refreshing. We pitched our tents near a clear river and made a campfire at night. We cooked delicious traditional food and told fascinating stories under the bright stars. It was a wonderful experience that brought us closer together, and we promised to visit again next year.",
    contentAr:
      "في الصيف الماضي، سافرت أنا وأصدقائي إلى الجبال الخضراء الجميلة. كان الطقس معتدلاً ومنعشاً. أقمنا خيامنا بالقرب من نهر صافٍ وأشعلنا نار المخيم في الليل. طبخنا طعاماً تقليدياً لذيذاً وروينا قصصاً مشوقة تحت النجوم اللامعة. كانت تجربة رائعة قربتنا من بعضنا، ووعدنا أن نزور المكان مجدداً العام القادم.",
    questions: [
      {
        qEn: "Where did they pitch their tents?",
        qAr: "أين أقاموا خيامهم؟",
        options: ["In a hotel", "Near a clear river", "In the desert"],
        correctIndex: 1,
        explanation: "النص يذكر: 'We pitched our tents near a clear river.'",
      },
    ],
  },
];

export default function ReadingWritingPage() {
  const [activeTab, setActiveTab] = useState<"reading" | "writing">("reading");
  const [selectedStory, setSelectedStory] = useState(stories[0]);
  const [showArabic, setShowArabic] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizFeedback, setQuizFeedback] = useState<Record<number, boolean>>({});

  // Writing state
  const [writingPrompt, setWritingPrompt] = useState("introduce");
  const [userText, setUserText] = useState("");
  const [writingSubmitted, setWritingSubmitted] = useState(false);

  const prompts = [
    {
      id: "introduce",
      title: "قدم نفسك (Introduce Yourself)",
      guidance: "اكتب 3 إلى 5 جمل عن اسمك، عمرك، مدينتك، وهوايتك المفضلة.",
      starter: "Hello! My name is ... I am from ... I like ...",
    },
    {
      id: "routine",
      title: "روتينك اليومي (Your Daily Routine)",
      guidance: "اكتب عن الأنشطة التي تقوم بها يومياً باستخدام المضارع البسيط.",
      starter: "Every day, I usually wake up at ... Then I ...",
    },
    {
      id: "vacation",
      title: "رسالة بريد إلكتروني عن إجازتك (Vacation Email)",
      guidance: "اكتب إيميل قصير لصديقك تخبره عن مكان زرته وماذا فعلت هناك.",
      starter: "Dear friend, I am writing to tell you about my vacation in ...",
    },
  ];

  const currentPrompt = prompts.find((p) => p.id === writingPrompt) || prompts[0];

  const handleCheckQuestion = (qIndex: number, optIndex: number, correctIndex: number) => {
    setQuizAnswers((prev) => ({ ...prev, [qIndex]: optIndex }));
    const isCorrect = optIndex === correctIndex;
    if (isCorrect) playSoundEffect("correct");
    else playSoundEffect("wrong");
    setQuizFeedback((prev) => ({ ...prev, [qIndex]: isCorrect }));
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-semibold">
            <FileText className="w-3.5 h-3.5" />
            <span>مهارات القراءة وفهم النصوص والتعبير الكتابي</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white">
            القراءة والكتابة باللغة الإنجليزية
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            قصص قصيرة متدرجة الصعوبة مع صوت فوري وترجمة، وقسم تدريب كتابي مع توجيهات مساعدة.
          </p>

          {/* Tab Selector */}
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={() => setActiveTab("reading")}
              className={`px-6 py-2.5 rounded-2xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                activeTab === "reading"
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>قسم القراءة وفهم المقروء (Reading)</span>
            </button>
            <button
              onClick={() => setActiveTab("writing")}
              className={`px-6 py-2.5 rounded-2xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
                activeTab === "writing"
                  ? "bg-purple-600 text-white shadow-lg shadow-purple-600/30"
                  : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
              }`}
            >
              <PenTool className="w-4 h-4" />
              <span>محرر التدريب على الكتابة (Writing)</span>
            </button>
          </div>
        </div>

        {activeTab === "reading" ? (
          <div className="space-y-6">
            {/* Story Picker Chips */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
              {stories.map((story) => (
                <button
                  key={story.id}
                  onClick={() => {
                    setSelectedStory(story);
                    setQuizAnswers({});
                    setQuizFeedback({});
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition flex items-center gap-2 cursor-pointer ${
                    selectedStory.id === story.id
                      ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
                      : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
                  }`}
                >
                  <LevelBadge level={story.level} size="sm" />
                  <span>{story.titleAr}</span>
                </button>
              ))}
            </div>

            {/* Story Card */}
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <LevelBadge level={selectedStory.level} size="sm" />
                    <span className="text-xs text-indigo-400 font-medium en-ltr">
                      {selectedStory.titleEn}
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-white">{selectedStory.titleAr}</h2>
                </div>

                <div className="flex items-center gap-2">
                  <AudioButton text={selectedStory.contentEn} size="md" showSlowToggle={true} />
                  <button
                    type="button"
                    onClick={() => setShowArabic(!showArabic)}
                    className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 border border-slate-700 transition"
                  >
                    {showArabic ? "إخفاء الترجمة" : "عرض الترجمة العربية"}
                  </button>
                </div>
              </div>

              {/* Story Body */}
              <div className="p-6 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-4">
                <p className="text-base sm:text-lg leading-relaxed text-slate-100 en-ltr font-serif">
                  {selectedStory.contentEn}
                </p>

                {showArabic && (
                  <div className="pt-4 border-t border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {selectedStory.contentAr}
                  </div>
                )}
              </div>

              {/* Comprehension Questions */}
              <div className="space-y-4 pt-2">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-indigo-400" />
                  <span>أسئلة فهم المقروء (Comprehension Questions):</span>
                </h3>

                <div className="space-y-4">
                  {selectedStory.questions.map((q, qIdx) => (
                    <div
                      key={qIdx}
                      className="p-5 rounded-2xl bg-slate-950/50 border border-slate-800 space-y-3"
                    >
                      <div className="space-y-0.5">
                        <p className="text-sm font-bold text-white en-ltr">
                          {qIdx + 1}. {q.qEn}
                        </p>
                        <p className="text-xs text-slate-400">{q.qAr}</p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        {q.options.map((opt, optIdx) => {
                          const isSelected = quizAnswers[qIdx] === optIdx;
                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleCheckQuestion(qIdx, optIdx, q.correctIndex)}
                              className={`p-3 rounded-xl text-xs font-bold en-ltr border transition text-center cursor-pointer ${
                                isSelected
                                  ? optIdx === q.correctIndex
                                    ? "bg-emerald-600 text-white border-emerald-400"
                                    : "bg-rose-600 text-white border-rose-400"
                                  : "bg-slate-900 hover:bg-slate-800 text-slate-200 border-slate-800"
                              }`}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>

                      {quizFeedback[qIdx] !== undefined && (
                        <p className="text-xs text-indigo-300 bg-slate-900 p-2.5 rounded-xl border border-slate-800 mt-2">
                          💡 <strong>تفسير الإجابة:</strong> {q.explanation}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Writing Studio Tab */
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-white">محرر التعبير والكتابة الإنجليزية</h2>
              <p className="text-xs text-slate-400 mt-1">
                اختر موضوعاً، اتبع الإرشادات، واكتب نصك بالإنجليزية لتطوير مهارة التعبير.
              </p>
            </div>

            {/* Prompt Selector */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {prompts.map((p) => (
                <button
                  key={p.id}
                  onClick={() => {
                    setWritingPrompt(p.id);
                    setUserText(p.starter);
                    setWritingSubmitted(false);
                  }}
                  className={`p-4 rounded-2xl text-right transition flex flex-col justify-between cursor-pointer ${
                    writingPrompt === p.id
                      ? "bg-purple-600 text-white ring-2 ring-purple-400 shadow-lg shadow-purple-600/25"
                      : "bg-slate-950/80 hover:bg-slate-800 border border-slate-800 text-slate-300"
                  }`}
                >
                  <p className="font-bold text-sm">{p.title}</p>
                  <p className="text-[11px] opacity-80 mt-2 leading-relaxed">{p.guidance}</p>
                </button>
              ))}
            </div>

            {/* Text Editor */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>اكتب نصك هنا باللغة الإنجليزية:</span>
                <span>
                  عدد الكلمات: {userText.trim().split(/\s+/).filter(Boolean).length} | الحروف: {userText.length}
                </span>
              </div>

              <textarea
                rows={6}
                value={userText}
                onChange={(e) => setUserText(e.target.value)}
                placeholder="Start typing your English paragraph here..."
                className="w-full p-4 rounded-2xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500 en-ltr font-mono leading-relaxed"
              ></textarea>
            </div>

            {/* Submit & Audio playback of user writing */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <AudioButton text={userText || "Please type some text first."} size="md" />

              <button
                type="button"
                onClick={() => {
                  setWritingSubmitted(true);
                  playSoundEffect("fanfare");
                }}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg flex items-center gap-2 transition"
              >
                <Send className="w-4 h-4" />
                <span>حفظ النص والتقييم</span>
              </button>
            </div>

            {writingSubmitted && (
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs space-y-1 animate-in fade-in">
                <p className="font-bold">🎉 عمل رائع ومجهود ممتاز!</p>
                <p className="text-slate-300">
                  تم حفظ نصك. استمع لنطق ما كتبته من زر الاستماع الصوتي أعلاه لتكراره بصوتك وتحسين سلاسة التعبير.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
