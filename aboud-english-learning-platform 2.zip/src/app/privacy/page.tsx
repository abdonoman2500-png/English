import React from "react";
import { ShieldCheck, Lock, Eye, Mic } from "lucide-react";

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-blue-500/10 border border-blue-500/30 text-blue-300 text-xs font-semibold">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>سياسة الخصوصية وأمن البيانات</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white">سياسة الخصوصية</h1>
          <p className="text-xs sm:text-sm text-slate-400">آخر تحديث: 2025</p>
        </div>

        <div className="p-8 sm:p-10 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6 text-xs sm:text-sm text-slate-300 leading-relaxed shadow-xl">
          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-indigo-400" />
              <span>1. حماية بيانات الحساب الشخصي</span>
            </h2>
            <p>
              نحن في «منصة عبود لتعلّم اللغة الإنجليزية» نلتزم التزاماً تاماً بحماية خصوصية مستخدمينا. لا نقوم بمشاركة بياناتك الشخصية (مثل الاسم أو البريد الإلكتروني) مع أي طرف ثالث لأغراض تسويقية أو تجارية.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Mic className="w-4 h-4 text-purple-400" />
              <span>2. إذن الميكروفون والتسجيل الصوتي</span>
            </h2>
            <p>
              عند استخدام ميزة تدريب النطق والتحدث في المحادثات، يطلب المتصفح إذن الوصول إلى الميكروفون. تُعالج الأصوات محلياً عبر تقنية Web Speech API المدمجة بمتصفحك، ولا يتم تخزين أي تسجيلات صوتية خاصة على خوادمنا دون موافقتك.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>3. حفظ التقدم والشهادات</span>
            </h2>
            <p>
              يتم حفظ بيانات تقدمك الأكاديمي، ونقاط الخبرة (XP)، والكلمات المفضلة، وسجل الاختبارات وشهادات الإتمام داخل قاعدة بيانات آمنة ومحمية بجلسات تسجيل دخول مشفرة.
            </p>
          </section>

          <section className="space-y-2">
            <h2 className="text-lg font-bold text-white">4. ملفات تعريف الارتباط (Cookies)</h2>
            <p>
              نستخدم ملفات تعريف الارتباط الأساسية لتمكين جلسة تسجيل الدخول الآمنة وتذكر تفضيلات المظهر (الوضع الليلي والنهاري).
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
