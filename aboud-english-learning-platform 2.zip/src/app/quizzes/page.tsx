"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import { playSoundEffect } from "@/lib/speech";
import confetti from "canvas-confetti";
import {
  Gamepad2,
  Sparkles,
  Award,
  CheckCircle2,
  XCircle,
  Timer,
  RotateCcw,
  BookOpen,
  Check,
  Zap,
} from "lucide-react";

interface QuizQuestion {
  id: number;
  type: string;
  promptEn: string;
  promptAr: string;
  options: string[];
  correctIndex: number;
  explanationAr: string;
}

interface QuizItem {
  id: number;
  titleAr: string;
  titleEn: string;
  levelCode: string;
  category: string;
  passScore: number;
  timeLimitMinutes: number;
  xpReward: number;
  questionsJson: string;
}

export default function QuizzesPage() {
  const { user, refreshUser } = useAuth();
  const [quizzes, setQuizzes] = useState<QuizItem[]>([]);
  const [selectedQuiz, setSelectedQuiz] = useState<QuizItem | null>(null);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, number>>({});
  const [quizFinished, setQuizFinished] = useState(false);
  const [result, setResult] = useState<any>(null);

  useEffect(() => {
    async function loadQuizzes() {
      try {
        const res = await fetch("/api/quizzes");
        const data = await res.json();
        if (data.quizzes && data.quizzes.length > 0) {
          setQuizzes(data.quizzes);
          setSelectedQuiz(data.quizzes[0]);
        }
      } catch (err) {
        console.error("Fetch quizzes failed", err);
      }
    }
    loadQuizzes();
  }, []);

  const parsedQuestions: QuizQuestion[] = selectedQuiz ? JSON.parse(selectedQuiz.questionsJson) : [];
  const activeQuestion = parsedQuestions[currentQIndex];

  const handleAnswerSelect = (optionIdx: number) => {
    setUserAnswers((prev) => ({
      ...prev,
      [currentQIndex]: optionIdx,
    }));
    playSoundEffect("click");
  };

  const handleFinishQuiz = async () => {
    if (!selectedQuiz) return;

    let correct = 0;
    parsedQuestions.forEach((q, idx) => {
      if (userAnswers[idx] === q.correctIndex) {
        correct++;
      }
    });

    const scorePct = Math.round((correct / parsedQuestions.length) * 100);
    const passed = scorePct >= selectedQuiz.passScore;

    try {
      const res = await fetch("/api/quizzes/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          quizId: selectedQuiz.id,
          answers: userAnswers,
        }),
      });
      const data = await res.json();
      setResult(data);
    } catch {
      setResult({
        score: scorePct,
        correctCount: correct,
        totalQuestions: parsedQuestions.length,
        passed,
        xpGained: passed ? selectedQuiz.xpReward : 10,
      });
    }

    setQuizFinished(true);

    if (passed) {
      playSoundEffect("fanfare");
      try {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      } catch {}
    } else {
      playSoundEffect("wrong");
    }

    await refreshUser();
  };

  const handleRestartQuiz = () => {
    setUserAnswers({});
    setCurrentQIndex(0);
    setQuizFinished(false);
    setResult(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-pink-500/10 border border-pink-500/30 text-pink-300 text-xs font-semibold mb-2">
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>بنك الاختبارات والتحديات التفاعلية</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
              الاختبارات التفاعلية والألعاب
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              اختبر معلوماتك في القواعد والمفردات مع تفسيرات علمية لكل إجابة وحصد نقاط XP.
            </p>
          </div>

          <Link
            href="/games"
            className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 text-white font-bold text-xs shadow-lg inline-flex items-center gap-2 self-start md:self-auto transition"
          >
            <Sparkles className="w-4 h-4" />
            <span>الألعاب التعليمية السريعة (Mini Games) 🎮</span>
          </Link>
        </div>

        {/* Quiz Picker Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {quizzes.map((q) => {
            const isSelected = selectedQuiz?.id === q.id;
            return (
              <button
                key={q.id}
                onClick={() => {
                  setSelectedQuiz(q);
                  handleRestartQuiz();
                }}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold shrink-0 transition flex items-center gap-2 cursor-pointer ${
                  isSelected
                    ? "bg-indigo-600 text-white ring-2 ring-indigo-400 shadow-lg shadow-indigo-600/30"
                    : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
                }`}
              >
                <LevelBadge level={q.levelCode} size="sm" />
                <span>{q.titleAr}</span>
              </button>
            );
          })}
        </div>

        {selectedQuiz && parsedQuestions.length > 0 && (
          <div>
            {!quizFinished ? (
              <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
                {/* Status Bar */}
                <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-300">
                      السؤال {currentQIndex + 1} من {parsedQuestions.length}
                    </span>
                    <LevelBadge level={selectedQuiz.levelCode} size="sm" />
                  </div>

                  <div className="flex items-center gap-2 text-xs font-bold text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                    <Zap className="w-3.5 h-3.5" />
                    <span>مكافأة: +{selectedQuiz.xpReward} XP</span>
                  </div>
                </div>

                {/* Question */}
                <div className="space-y-3 py-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-2xl font-bold text-white en-ltr">
                      {activeQuestion.promptEn}
                    </h3>
                    <AudioButton text={activeQuestion.promptEn} size="sm" />
                  </div>
                  <p className="text-sm text-indigo-300">{activeQuestion.promptAr}</p>
                </div>

                {/* Options Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {activeQuestion.options.map((opt, optIdx) => {
                    const isSelected = userAnswers[currentQIndex] === optIdx;
                    return (
                      <button
                        key={optIdx}
                        onClick={() => handleAnswerSelect(optIdx)}
                        className={`p-4 rounded-2xl flex items-center justify-between text-right transition-all cursor-pointer ${
                          isSelected
                            ? "bg-indigo-600/30 text-white border-2 border-indigo-500 shadow-lg shadow-indigo-600/20"
                            : "bg-slate-800/70 hover:bg-slate-800 text-slate-200 border border-slate-700/60 hover:border-slate-600"
                        }`}
                      >
                        <span className="font-semibold text-sm en-ltr">{opt}</span>
                        <span
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold shrink-0 ${
                            isSelected ? "bg-indigo-500 text-white" : "bg-slate-700 text-slate-400"
                          }`}
                        >
                          {isSelected ? <Check className="w-3.5 h-3.5" /> : optIdx + 1}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Navigation */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                  <button
                    disabled={currentQIndex === 0}
                    onClick={() => setCurrentQIndex((p) => p - 1)}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold disabled:opacity-40 transition"
                  >
                    السابق
                  </button>

                  {currentQIndex < parsedQuestions.length - 1 ? (
                    <button
                      onClick={() => setCurrentQIndex((p) => p + 1)}
                      className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-lg shadow-indigo-600/20"
                    >
                      السؤال التالي
                    </button>
                  ) : (
                    <button
                      onClick={handleFinishQuiz}
                      className="px-8 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold transition shadow-lg shadow-emerald-600/20"
                    >
                      إنهاء الاختبار وعرض النتيجة
                    </button>
                  )}
                </div>
              </div>
            ) : (
              /* Quiz Finished View */
              <div className="p-8 rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl space-y-6 text-center animate-in fade-in">
                <div
                  className={`w-16 h-16 rounded-3xl flex items-center justify-center mx-auto shadow-xl ${
                    result?.passed
                      ? "bg-emerald-500/20 text-emerald-400 shadow-emerald-500/20"
                      : "bg-rose-500/20 text-rose-400 shadow-rose-500/20"
                  }`}
                >
                  {result?.passed ? <Award className="w-8 h-8" /> : <XCircle className="w-8 h-8" />}
                </div>

                <div>
                  <h2 className="text-3xl font-extrabold text-white">
                    {result?.passed ? "تهانينا! اجتزت الاختبار بنجاح 🎉" : "للأسف لم تجتز درجة النجاح المطلوبة"}
                  </h2>
                  <p className="text-sm text-slate-300 mt-2">
                    الدرجة: <span className="font-bold text-white">{result?.score}%</span> • شرط النجاح: {selectedQuiz.passScore}%
                  </p>
                  <p className="text-xs text-indigo-400 font-semibold mt-1">
                    +{result?.xpGained || 25} XP تم إضافتها لملفك!
                  </p>
                </div>

                {/* Explanations */}
                <div className="space-y-3 text-right max-w-2xl mx-auto pt-2">
                  <h4 className="font-bold text-sm text-white">مراجعة الأسئلة والتفسيرات:</h4>
                  {parsedQuestions.map((q, idx) => {
                    const uAns = userAnswers[idx];
                    const isRight = uAns === q.correctIndex;
                    return (
                      <div
                        key={q.id}
                        className={`p-4 rounded-2xl border text-xs space-y-1 ${
                          isRight
                            ? "bg-emerald-950/20 border-emerald-500/30"
                            : "bg-rose-950/20 border-rose-500/30"
                        }`}
                      >
                        <p className="font-bold text-white en-ltr">
                          {idx + 1}. {q.promptEn}
                        </p>
                        <p className="text-slate-300">{q.promptAr}</p>
                        <p className="text-indigo-300 pt-1">💡 <strong>التفسير:</strong> {q.explanationAr}</p>
                      </div>
                    );
                  })}
                </div>

                <div className="flex items-center justify-center gap-3 pt-4">
                  <button
                    onClick={handleRestartQuiz}
                    className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs inline-flex items-center gap-2 transition"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>إعادة الاختبار</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
