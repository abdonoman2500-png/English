"use client";

import React, { useState, useEffect } from "react";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import { playEnglishText, stopSpeaking } from "@/lib/speech";
import {
  MessageSquare,
  Sparkles,
  Volume2,
  Mic,
  MicOff,
  Eye,
  EyeOff,
  Play,
  Square,
  CheckCircle2,
  HelpCircle,
  Lightbulb,
} from "lucide-react";

interface DialogueLine {
  speaker: string;
  en: string;
  ar: string;
}

interface ConversationItem {
  id: number;
  titleAr: string;
  titleEn: string;
  scenario: string;
  levelCode: string;
  grammarNotesAr: string;
  dialogueJson: string;
}

export default function ConversationsPage() {
  const [conversations, setConversations] = useState<ConversationItem[]>([]);
  const [selectedConv, setSelectedConv] = useState<ConversationItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [showTranslation, setShowTranslation] = useState(true);
  const [isPlayingFull, setIsPlayingFull] = useState(false);
  const [currentPlayingLineIndex, setCurrentPlayingLineIndex] = useState<number | null>(null);

  // Voice recording & comparison practice state
  const [isRecording, setIsRecording] = useState(false);
  const [recordedText, setRecordedText] = useState("");
  const [activeRecordingLineIndex, setActiveRecordingLineIndex] = useState<number | null>(null);
  const [micError, setMicError] = useState("");

  useEffect(() => {
    async function fetchConversations() {
      try {
        const res = await fetch("/api/conversations");
        const data = await res.json();
        if (data.conversations && data.conversations.length > 0) {
          setConversations(data.conversations);
          setSelectedConv(data.conversations[0]);
        }
      } catch (err) {
        console.error("Fetch conversations failed", err);
      } finally {
        setLoading(false);
      }
    }
    fetchConversations();
  }, []);

  const parsedDialogue: DialogueLine[] = selectedConv ? JSON.parse(selectedConv.dialogueJson) : [];

  const handlePlayFullConversation = async () => {
    if (isPlayingFull) {
      stopSpeaking();
      setIsPlayingFull(false);
      setCurrentPlayingLineIndex(null);
      return;
    }

    setIsPlayingFull(true);
    for (let i = 0; i < parsedDialogue.length; i++) {
      setCurrentPlayingLineIndex(i);
      await playEnglishText(parsedDialogue[i].en, 0.9);
      // Brief pause between speakers
      await new Promise((r) => setTimeout(r, 600));
    }
    setIsPlayingFull(false);
    setCurrentPlayingLineIndex(null);
  };

  // Web Speech Recognition for practicing pronunciation
  const startRecordingPractice = (lineIndex: number, targetText: string) => {
    setMicError("");
    setRecordedText("");
    setActiveRecordingLineIndex(lineIndex);

    // Check if browser supports SpeechRecognition
    const SpeechRec =
      (window as unknown as { SpeechRecognition?: any }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: any }).webkitSpeechRecognition;

    if (!SpeechRec) {
      setMicError("متصفحك لا يدعم التعرف الصوتي المباشر. ننصح باستخدام Google Chrome أو Safari الحديث.");
      return;
    }

    try {
      const recognition = new SpeechRec();
      recognition.lang = "en-US";
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      setIsRecording(true);

      recognition.onresult = (event: any) => {
        const spoken = event.results[0][0].transcript;
        setRecordedText(spoken);
        setIsRecording(false);
      };

      recognition.onerror = (event: any) => {
        console.warn("Speech recognition error:", event.error);
        if (event.error === "not-allowed") {
          setMicError("تم رفض إذن الميكروفون. يرجى السماح للمتصفح بالوصول إلى الميكروفون.");
        } else {
          setMicError("لم نتمكن من التقاط الصوت بوضوح، يرجى المحاولة مجدداً والتحدث بوضوح.");
        }
        setIsRecording(false);
      };

      recognition.onend = () => {
        setIsRecording(false);
      };

      recognition.start();
    } catch (err) {
      console.error("Mic start failed", err);
      setMicError("فشل تشغيل الميكروفون");
      setIsRecording(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>محادثات باللغة الإنجليزية في الحياة اليومية</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white">
            المحادثات التفاعلية وتدريبات التحدث
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            استمع لحوارات واقعية كاملة، اختبر فهمك بإخفاء الترجمة، ومارس نطقك عبر ميكروفون المتصفح مع مقارنة فورية.
          </p>
        </div>

        {/* Conversation Selector Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {conversations.map((conv) => {
            const isSelected = selectedConv?.id === conv.id;
            return (
              <button
                key={conv.id}
                onClick={() => {
                  stopSpeaking();
                  setIsPlayingFull(false);
                  setSelectedConv(conv);
                }}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold shrink-0 transition flex items-center gap-2 cursor-pointer ${
                  isSelected
                    ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 ring-2 ring-indigo-400"
                    : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
                }`}
              >
                <LevelBadge level={conv.levelCode} size="sm" />
                <span>{conv.titleAr}</span>
              </button>
            );
          })}
        </div>

        {selectedConv && (
          <div className="space-y-6">
            {/* Top Toolbar */}
            <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <LevelBadge level={selectedConv.levelCode} size="sm" />
                  <span className="text-xs font-semibold text-indigo-400">
                    السيناريو: {selectedConv.scenario}
                  </span>
                </div>
                <h2 className="text-2xl font-bold text-white">{selectedConv.titleAr}</h2>
                <p className="text-xs text-slate-400 en-ltr">{selectedConv.titleEn}</p>
              </div>

              {/* Controls */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={handlePlayFullConversation}
                  className={`px-5 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition shadow-lg ${
                    isPlayingFull
                      ? "bg-rose-600 text-white shadow-rose-600/20"
                      : "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-indigo-600/20"
                  }`}
                >
                  {isPlayingFull ? <Square className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
                  <span>{isPlayingFull ? "إيقاف التشغيل" : "تشغيل الحوار كاملاً 🔊"}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowTranslation(!showTranslation)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition"
                >
                  {showTranslation ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  <span>{showTranslation ? "إخفاء الترجمة" : "إظهار الترجمة"}</span>
                </button>
              </div>
            </div>

            {/* Grammar / Cultural Notes Tip */}
            {selectedConv.grammarNotesAr && (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 flex items-start gap-2.5">
                <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <p><strong>ملاحظة لغوية:</strong> {selectedConv.grammarNotesAr}</p>
              </div>
            )}

            {/* Mic Error Banner if any */}
            {micError && (
              <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs text-center">
                {micError}
              </div>
            )}

            {/* Dialogue Exchange View */}
            <div className="space-y-4">
              {parsedDialogue.map((line, idx) => {
                const isHighlight = currentPlayingLineIndex === idx;
                const isSpeakerA = idx % 2 === 0;

                return (
                  <div
                    key={idx}
                    className={`p-5 rounded-3xl border transition-all duration-200 ${
                      isHighlight
                        ? "bg-indigo-950/70 border-indigo-400 ring-2 ring-indigo-500 shadow-xl"
                        : isSpeakerA
                        ? "bg-slate-900/90 border-slate-800 text-right"
                        : "bg-slate-900/60 border-slate-800/80 mr-4 sm:mr-10"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-3 mb-2">
                      <span className="text-xs font-bold text-indigo-400">{line.speaker}</span>

                      <div className="flex items-center gap-2">
                        <AudioButton text={line.en} size="sm" showSlowToggle={true} />

                        <button
                          type="button"
                          onClick={() => startRecordingPractice(idx, line.en)}
                          title="تدرّب على نطق هذه الجملة بصوتك"
                          className={`p-1.5 rounded-lg text-xs flex items-center gap-1 transition ${
                            isRecording && activeRecordingLineIndex === idx
                              ? "bg-rose-600 text-white animate-pulse"
                              : "bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-emerald-400 border border-slate-700"
                          }`}
                        >
                          <Mic className="w-3.5 h-3.5" />
                          <span className="hidden sm:inline text-[11px]">
                            {isRecording && activeRecordingLineIndex === idx ? "جارٍ الاستماع..." : "تحدث"}
                          </span>
                        </button>
                      </div>
                    </div>

                    <p className="text-base sm:text-lg font-bold text-white en-ltr leading-relaxed">
                      {line.en}
                    </p>

                    {showTranslation && (
                      <p className="text-xs sm:text-sm text-slate-400 mt-1.5 leading-relaxed">
                        {line.ar}
                      </p>
                    )}

                    {/* Show Spoken Result for this line */}
                    {activeRecordingLineIndex === idx && recordedText && (
                      <div className="mt-3 p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1">
                        <p className="text-slate-400">
                          صوتك المسجل: <span className="text-emerald-400 font-bold en-ltr">"{recordedText}"</span>
                        </p>
                        <p className="text-[11px] text-slate-500">
                          نصيحة: قارن نطقك بصوت التسجيل النموذجي من خلال زر الاستماع أعلاه.
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
