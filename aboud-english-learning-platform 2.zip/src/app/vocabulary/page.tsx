"use client";

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import {
  Search,
  Bookmark,
  BookmarkCheck,
  Sparkles,
  Volume2,
  Filter,
  CheckCircle2,
  Loader2,
  Layers,
  BookOpen,
} from "lucide-react";

interface WordItem {
  id: number;
  word: string;
  phonetic: string;
  partOfSpeech: string;
  translationAr: string;
  levelCode: string;
  category: string;
  exampleEn: string;
  exampleAr: string;
  isFavorite: boolean;
  isMastered: boolean;
}

export default function VocabularyPage() {
  const { user } = useAuth();
  const [words, setWords] = useState<WordItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [levelFilter, setLevelFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [togglingId, setTogglingId] = useState<number | null>(null);

  const categories = [
    { id: "all", label: "جميع الأقسام" },
    { id: "basics", label: "الأساسيات والتحيات" },
    { id: "family", label: "العائلة والناس" },
    { id: "food", label: "الطعام والمطاعم" },
    { id: "travel", label: "السفر والمطارات" },
    { id: "business", label: "العمل والتجارة" },
    { id: "idioms", label: "التعبيرات الاصطلاحية (Idioms)" },
    { id: "academic", label: "المفردات الأكاديمية" },
  ];

  const levels = ["all", "Pre-A1", "A1", "A2", "B1", "B2", "C1", "C2"];

  useEffect(() => {
    async function fetchVocabulary() {
      setLoading(true);
      try {
        const queryParams = new URLSearchParams();
        if (search) queryParams.set("search", search);
        if (levelFilter !== "all") queryParams.set("level", levelFilter);
        if (categoryFilter !== "all") queryParams.set("category", categoryFilter);

        const res = await fetch(`/api/vocabulary?${queryParams.toString()}`);
        const data = await res.json();
        if (data.vocabulary) {
          setWords(data.vocabulary);
        }
      } catch (err) {
        console.error("Vocabulary fetch failed", err);
      } finally {
        setLoading(false);
      }
    }

    const timer = setTimeout(() => {
      fetchVocabulary();
    }, 200);

    return () => clearTimeout(timer);
  }, [search, levelFilter, categoryFilter]);

  const handleToggleFavorite = async (vocabId: number) => {
    if (!user) {
      alert("يرجى تسجيل الدخول لحفظ الكلمات في المفضلة");
      return;
    }

    setTogglingId(vocabId);
    try {
      const res = await fetch("/api/vocabulary/favorite", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ vocabId }),
      });
      const data = await res.json();

      if (data.success) {
        setWords((prev) =>
          prev.map((w) => (w.id === vocabId ? { ...w, isFavorite: data.isFavorite } : w))
        );
      }
    } catch (err) {
      console.error("Toggle favorite failed", err);
    } finally {
      setTogglingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>بنك الكلمات والقاموس التفاعلي</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white">
              المفردات والقاموس الإنجليزي
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              مفردات مصنفة حسب مستويات CEFR مع النطق الصوتي الفوري، الرموز الصوتية، وأمثلة الجمل.
            </p>
          </div>

          <Link
            href="/favorites"
            className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-slate-950 font-bold text-xs shadow-lg shadow-amber-600/20 inline-flex items-center gap-2 self-start md:self-auto transition"
          >
            <Bookmark className="w-4 h-4" />
            <span>مراجعة بطاقات المفضلة (Flashcards)</span>
          </Link>
        </div>

        {/* Search & Filter Controls */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4 shadow-xl">
          {/* Search bar */}
          <div className="relative">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث بالإنجليزية أو العربية (مثال: Opportunity أو فرصة)..."
              className="w-full px-4 py-3 pl-11 rounded-2xl bg-slate-800/80 border border-slate-700 text-white placeholder-slate-400 text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-right"
            />
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
          </div>

          {/* Level Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            <span className="text-xs font-semibold text-slate-400 shrink-0 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              المستوى:
            </span>
            {levels.map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLevelFilter(lvl)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition ${
                  levelFilter === lvl
                    ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/20"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {lvl === "all" ? "جميع المستويات" : lvl}
              </button>
            ))}
          </div>

          {/* Category Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            <span className="text-xs font-semibold text-slate-400 shrink-0 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5" />
              الموضوع:
            </span>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategoryFilter(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition ${
                  categoryFilter === cat.id
                    ? "bg-purple-600 text-white shadow-md shadow-purple-600/20"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Vocabulary Grid */}
        {loading ? (
          <div className="py-20 text-center space-y-3">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-400 mx-auto" />
            <p className="text-xs text-slate-400">جارٍ جلب المفردات...</p>
          </div>
        ) : words.length === 0 ? (
          <div className="p-12 rounded-3xl bg-slate-900/60 border border-slate-800 text-center space-y-3">
            <BookOpen className="w-10 h-10 text-slate-500 mx-auto" />
            <h3 className="text-lg font-bold text-white">لم يتم العثور على كلمات مطابقة</h3>
            <p className="text-xs text-slate-400">جرب البحث بكلمة أخرى أو تغيير معايير التصفية</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {words.map((item) => (
              <div
                key={item.id}
                className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/90 hover:border-indigo-500/40 transition duration-200 flex flex-col justify-between shadow-xl group"
              >
                <div>
                  {/* Top Bar: Badges & Favorite */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <LevelBadge level={item.levelCode} size="sm" />
                      <span className="text-[11px] px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 font-medium">
                        {item.partOfSpeech}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleFavorite(item.id)}
                      disabled={togglingId === item.id}
                      title={item.isFavorite ? "إزالة من المفضلة" : "حفظ في المفضلة"}
                      className={`p-2 rounded-xl transition ${
                        item.isFavorite
                          ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                          : "bg-slate-800 text-slate-400 hover:text-white"
                      }`}
                    >
                      {item.isFavorite ? (
                        <BookmarkCheck className="w-4 h-4" />
                      ) : (
                        <Bookmark className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  {/* Word Header */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-2xl font-bold text-white en-ltr group-hover:text-indigo-300 transition">
                        {item.word}
                      </h3>
                      <AudioButton
                        text={`${item.word}. ${item.exampleEn || ""}`}
                        size="sm"
                        showSlowToggle={true}
                      />
                    </div>
                    {item.phonetic && (
                      <p className="text-xs text-indigo-400 font-mono en-ltr">{item.phonetic}</p>
                    )}
                  </div>

                  {/* Arabic Translation */}
                  <div className="mt-3 pt-3 border-t border-slate-800">
                    <p className="text-sm font-semibold text-slate-100">{item.translationAr}</p>
                  </div>

                  {/* Example Sentence */}
                  {item.exampleEn && (
                    <div className="mt-3 p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 space-y-1 text-xs">
                      <p className="text-slate-200 en-ltr font-medium leading-relaxed">{item.exampleEn}</p>
                      <p className="text-slate-400 leading-relaxed">{item.exampleAr}</p>
                    </div>
                  )}
                </div>

                <div className="mt-4 pt-2 text-[11px] text-slate-500 flex items-center justify-between">
                  <span>التصنيف: {item.category}</span>
                  {item.isFavorite && (
                    <span className="text-amber-400 font-medium">★ محفوظة للمراجعة</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
