"use client";

import React, { useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { AudioButton } from "@/components/AudioButton";
import { LevelBadge } from "@/components/LevelBadge";
import { playSoundEffect } from "@/lib/speech";
import {
  Compass,
  Sparkles,
  BookOpen,
  CheckCircle2,
  HelpCircle,
  Volume2,
  Lightbulb,
  Check,
  X,
  Award,
} from "lucide-react";

interface GrammarLesson {
  id: string;
  level: string;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  formula: string;
  sections: Array<{
    heading: string;
    text: string;
    examples?: Array<{ en: string; ar: string }>;
  }>;
  quickCheck: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
}

const grammarLessons: GrammarLesson[] = [
  {
    id: "pronouns-to-be",
    level: "A1",
    titleAr: "الضمائر الشخصية وفعل الكينونة (Verb to Be)",
    titleEn: "Subject Pronouns & Verb To Be (am, is, are)",
    summaryAr: "الأساس الذي تُبنى عليه الجمل الإنجليزية البسيطة للتعبير عن الصفات والأسماء والمهن.",
    formula: "Subject + am / is / are + Complement (Noun / Adjective)",
    sections: [
      {
        heading: "1. جدول التصريف الأساسي",
        text: "• I + am -> I'm (أنا أكون)\n• He / She / It + is -> He's, She's, It's (هو/هي/هو لغير العاقل)\n• You / We / They + are -> You're, We're, They're (أنت/نحن/هم)",
        examples: [
          { en: "I am a diligent student.", ar: "أنا طالب مجتهد." },
          { en: "She is a doctor in the hospital.", ar: "هي طبيبة في المستشفى." },
          { en: "They are very friendly.", ar: "هم لطفاء جداً." },
        ],
      },
      {
        heading: "2. النفي وتكوين السؤال",
        text: "• النفي: نضيف not بعد الفعل مباشرة: (He is not tired / We aren't ready)\n• السؤال: نعكس الترتيب بين الفاعل والفعل: (Are you ready? / Is he here?)",
        examples: [
          { en: "He is not late for work.", ar: "هو ليس متأخراً عن العمل." },
          { en: "Are you ready for the test?", ar: "هل أنت مستعد للاختبار؟" },
        ],
      },
    ],
    quickCheck: {
      question: "اختر الكلمة الصحيحة: They ______ excellent engineers.",
      options: ["is", "are", "am"],
      correctIndex: 1,
      explanation: "ضمير الجمع They يأخذ are دائماً في المضارع.",
    },
  },
  {
    id: "present-simple",
    level: "A1",
    titleAr: "زمن المضارع البسيط (Present Simple)",
    titleEn: "Present Simple Tense (Habits & Facts)",
    summaryAr: "يُستخدم للحديث عن الروتين اليومي، العادات المتكررة، والحقائق العلمية الثابتة.",
    formula: "Subject + Verb(s/es مع He/She/It) + Object",
    sections: [
      {
        heading: "1. قاعدة الإثبات (Positive)",
        text: "• مع (I / You / We / They): نستخدم الفعل بدون أي إضافة (Play, Drink, Work)\n• مع (He / She / It): نضيف حرف s أو es إلى نهاية الفعل! (Plays, Drinks, Works)",
        examples: [
          { en: "I drink Arabic coffee every morning.", ar: "أنا أشرب القهوة العربية كل صباح." },
          { en: "He works at a technology company.", ar: "هو يعمل في شركة تقنية." },
        ],
      },
      {
        heading: "2. النفي والسؤال باستخدام Do و Does",
        text: "• النفي: don't مع الجمع، و doesn't مع المفرد (مع تجريد الفعل من الـ s)\n• السؤال: Do you...? أو Does he...?",
        examples: [
          { en: "I don't eat fast food.", ar: "أنا لا آكل الوجبات السريعة." },
          { en: "She doesn't speak French.", ar: "هي لا تتحدث الفرنسية." },
        ],
      },
    ],
    quickCheck: {
      question: "اختر الصحيح: Ahmed ______ football every Friday.",
      options: ["play", "plays", "playing"],
      correctIndex: 1,
      explanation: "أحمد اسم مفرد (يعادل He)، لذا نضيف s لنهاية الفعل في المضارع البسيط: plays.",
    },
  },
  {
    id: "present-continuous",
    level: "A1",
    titleAr: "زمن المضارع المستمر (Present Continuous)",
    titleEn: "Present Continuous: Actions Happening Now",
    summaryAr: "يُستخدم للأحداث التي تقع الآن في لحظة الكلام، أو للخطط المستقبلية المؤكدة.",
    formula: "Subject + am / is / are + Verb-ing",
    sections: [
      {
        heading: "1. التكوين والكلمات الدالة",
        text: "الكلمات الدالة: Now (الآن), At the moment (في هذه اللحظة), Look! (انظر!), Listen! (استمع!).",
        examples: [
          { en: "I am studying English right now.", ar: "أنا أدرس الإنجليزية في هذه اللحظة." },
          { en: "Look! It is raining outside.", ar: "انظر! إنها تمطر في الخارج." },
        ],
      },
    ],
    quickCheck: {
      question: "Listen! Someone ______ at the door.",
      options: ["knocks", "is knocking", "knocked"],
      correctIndex: 1,
      explanation: "كلمة Listen! تدل على أن الحدث يقع الآن في لحظة التحدث، لذا نستخدم is knocking.",
    },
  },
  {
    id: "past-simple",
    level: "A2",
    titleAr: "زمن الماضي البسيط (Past Simple Tense)",
    titleEn: "Past Simple: Regular & Irregular Verbs",
    summaryAr: "يُستخدم للأحداث والقصص التي بدأت وانتهت في وقت محدد في الماضي.",
    formula: "Subject + Verb(V2) + Complement",
    sections: [
      {
        heading: "1. الأفعال المنتظمة وغير المنتظمة (Regular vs Irregular)",
        text: "• الأفعال المنتظمة: نضيف ed (مثل: Watch -> Watched / Play -> Played)\n• الأفعال غير المنتظمة: تتغير وتُحفظ (مثل: Go -> Went / Buy -> Bought / See -> Saw)",
        examples: [
          { en: "Yesterday, I visited my grandparents.", ar: "أمس، زرت جدي وجدتي." },
          { en: "We went to Dubai last month.", ar: "ذهبنا إلى دبي الشهر الماضي." },
        ],
      },
      {
        heading: "2. النفي والسؤال في الماضي بـ Didn't",
        text: "نستخدم didn't للنفي + الفعل بالمصدر الأصلي: I didn't see him.",
        examples: [
          { en: "I didn't receive your email yesterday.", ar: "لم أستلم بريدك الإلكتروني بالأمس." },
        ],
      },
    ],
    quickCheck: {
      question: "They ______ a new car last week.",
      options: ["buy", "bought", "buying"],
      correctIndex: 1,
      explanation: "Last week تدل على الماضي البسيط، والتصريف الثاني الشاذ لـ buy هو bought.",
    },
  },
  {
    id: "future-tenses",
    level: "A2",
    titleAr: "أزمنة المستقبل (Future with Will vs Going to)",
    titleEn: "Future Simple: Will vs Be Going To",
    summaryAr: "الفرق الجوهري بين القرارات السريعة (Will) والخطط والنوايا المسبقة (Going to).",
    formula: "Will + Verb(base)  OR  am/is/are + going to + Verb(base)",
    sections: [
      {
        heading: "الفرق بين Will و Going to",
        text: "• Will: للقرارات اللحظية، الوعود، والتوقعات بدون دليل (I will help you!)\n• Going to: للخطط المسبقة والنوايا والتوقعات القائمة على دليل مرئي (I am going to travel next week)",
        examples: [
          { en: "I will call you tonight, I promise.", ar: "سأتصل بك الليلة، أعدك." },
          { en: "Look at the dark clouds! It is going to rain.", ar: "انظر إلى السحب الداكنة! إنها ستمطر." },
        ],
      },
    ],
    quickCheck: {
      question: "I have a plane ticket. I ______ to London tomorrow.",
      options: ["will travel", "am going to travel", "traveled"],
      correctIndex: 1,
      explanation: "وجود تذكرة طيران يعني خطة مسبقة وترتيباً مؤكداً، لذا نستخدم am going to travel.",
    },
  },
  {
    id: "present-perfect",
    level: "B1",
    titleAr: "زمن المضارع التام (Present Perfect Tense)",
    titleEn: "Present Perfect: have/has + V3",
    summaryAr: "ربط الماضي بالحاضر: تجارب حياتية بدون تحديد وقت، أو أفعال بدأت في الماضي ومستمرة.",
    formula: "Subject + have / has + Past Participle (V3)",
    sections: [
      {
        heading: "الكلمات الدالة الهامة (Since, For, Already, Yet, Ever)",
        text: "• Since: منذ وقت محدد (Since 2015)\n• For: لمدة زمنية إجمالية (For 5 years)\n• Ever: في الأسئلة (Have you ever been to Paris?)\n• Yet: في النفي والسؤال في النهاية (I haven't eaten yet)",
        examples: [
          { en: "I have lived in Riyadh since 2018.", ar: "عشت في الرياض منذ عام 2018 (وما زلت هناك)." },
          { en: "Have you ever tried traditional Arabic coffee?", ar: "هل جربت يوماً القهوة العربية التقليدية؟" },
        ],
      },
    ],
    quickCheck: {
      question: "She has worked in this company ______ three years.",
      options: ["since", "for", "ago"],
      correctIndex: 1,
      explanation: "نستخدم for لأن (3 years) تمثل مدة زمنية إجمالية وليس نقطة بداية محددة.",
    },
  },
  {
    id: "modal-verbs",
    level: "B1",
    titleAr: "الأفعال المساعدة الناقصة (Modal Verbs)",
    titleEn: "Modal Verbs: Can, Must, Should, May",
    summaryAr: "التعبير عن القدرة والإمكانية، النصيحة، والإلزام القانوني والأخلاقي.",
    formula: "Subject + Modal Verb + Verb(infinitive base)",
    sections: [
      {
        heading: "استخدامات الأفعال الناقصة",
        text: "• Can / Could: للقدرة والاستطاعة والطلب المهذب (Can you help me?)\n• Should: لتقديم النصيحة (You should sleep early)\n• Must: للإلزام والضرورة الحتمية (You must wear a seatbelt)\n• May / Might: للاحتمالية (It might rain tomorrow)",
        examples: [
          { en: "You must stop when the red light is on.", ar: "يجب عليك التوقف عندما تكون الإشارة حمراء." },
          { en: "You should drink more water.", ar: "ينبغي عليك شرب المزيد من الماء." },
        ],
      },
    ],
    quickCheck: {
      question: "You look tired. You ______ take a short break.",
      options: ["must", "should", "might not"],
      correctIndex: 1,
      explanation: "نستخدم should لتقديم نصيحة ودية مفيدة.",
    },
  },
  {
    id: "conditionals",
    level: "B2",
    titleAr: "الجمل الشرطية الأربعة (Conditionals 0, 1, 2, 3)",
    titleEn: "All If Conditional Clauses",
    summaryAr: "شرح شامل لقواعد If للتعبير عن الحقائق، التوقعات المستقبلية، الافتراضات، والندم.",
    formula: "Zero: If + Present, Present | 1st: If + Present, will | 2nd: If + Past, would | 3rd: If + Had V3, would have V3",
    sections: [
      {
        heading: "الحالات الشرطية الأربعة مع الأمثلة",
        text: "• Zero: (حقائق) If you heat water, it boils.\n• 1st: (مستقبل واقعي) If you study hard, you will pass.\n• 2nd: (افتراض خيالي في الحاضر) If I were rich, I would travel the world.\n• 3rd: (ندم على الماضي) If I had studied, I would have passed.",
        examples: [
          { en: "If it rains tomorrow, we will stay at home.", ar: "إذا أمطرت غداً، سنبقى في المنزل." },
          { en: "If I won the prize, I would buy a house.", ar: "لو فزت بالجائزة، لاشتريت منزلاً." },
        ],
      },
    ],
    quickCheck: {
      question: "If I ______ you, I would accept the job offer.",
      options: ["am", "were", "will be"],
      correctIndex: 1,
      explanation: "في الحالة الشرطية الثانية لتقديم النصيحة الافتراضية نستخدم If I were you.",
    },
  },
];

export default function GrammarPage() {
  const [selectedLevel, setSelectedLevel] = useState("all");
  const [activeLessonId, setActiveLessonId] = useState(grammarLessons[0].id);
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [quizFeedback, setQuizFeedback] = useState<Record<string, "correct" | "wrong">>({});

  const levels = ["all", "A1", "A2", "B1", "B2"];

  const filtered = grammarLessons.filter((l) => {
    if (selectedLevel === "all") return true;
    return l.level === selectedLevel;
  });

  const activeLesson = grammarLessons.find((l) => l.id === activeLessonId) || grammarLessons[0];

  const handleCheckAnswer = (lessonId: string, optionIndex: number, correctIndex: number) => {
    setQuizAnswers((prev) => ({ ...prev, [lessonId]: optionIndex }));
    const isCorrect = optionIndex === correctIndex;
    if (isCorrect) {
      playSoundEffect("correct");
      setQuizFeedback((prev) => ({ ...prev, [lessonId]: "correct" }));
    } else {
      playSoundEffect("wrong");
      setQuizFeedback((prev) => ({ ...prev, [lessonId]: "wrong" }));
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
            <Compass className="w-3.5 h-3.5" />
            <span>موسوعة القواعد الإنجليزية المبسطة (English Grammar)</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white">
            شرح قواعد اللغة الإنجليزية بالعربية
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            تعلم أسرار الأزمنة وتراكيب الجمل بسهولة مع معادلات بصرية وأمثلة صوتية وتمارين تفاعلية.
          </p>

          {/* Level Filter */}
          <div className="flex items-center justify-center gap-2 pt-2">
            {levels.map((lvl) => (
              <button
                key={lvl}
                onClick={() => setSelectedLevel(lvl)}
                className={`px-4 py-1.5 rounded-xl text-xs font-semibold transition ${
                  selectedLevel === lvl
                    ? "bg-indigo-600 text-white shadow-lg shadow-indigo-600/30"
                    : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
                }`}
              >
                {lvl === "all" ? "جميع المستويات" : `المستوى ${lvl}`}
              </button>
            ))}
          </div>
        </div>

        {/* 2-Column Layout: Lessons Sidebar & Active Lesson Viewer */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Sidebar List */}
          <div className="lg:col-span-4 space-y-2">
            <h3 className="text-sm font-bold text-slate-300 px-1 mb-2">قائمة دروس القواعد:</h3>
            <div className="space-y-2 max-h-[70vh] overflow-y-auto pr-1">
              {filtered.map((lesson) => {
                const isActive = lesson.id === activeLesson.id;
                return (
                  <button
                    key={lesson.id}
                    onClick={() => setActiveLessonId(lesson.id)}
                    className={`w-full p-4 rounded-2xl text-right transition flex flex-col gap-1.5 cursor-pointer ${
                      isActive
                        ? "bg-indigo-600 text-white shadow-xl shadow-indigo-600/25 ring-1 ring-indigo-400"
                        : "bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-300"
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <LevelBadge level={lesson.level} size="sm" />
                      <span className="text-[11px] opacity-80 en-ltr">{lesson.titleEn}</span>
                    </div>
                    <p className="font-bold text-sm text-white mt-1">{lesson.titleAr}</p>
                    <p className="text-[11px] opacity-75 line-clamp-1">{lesson.summaryAr}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Active Lesson Content */}
          <div className="lg:col-span-8 p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl space-y-6">
            {/* Lesson Title & Formula */}
            <div className="space-y-3 border-b border-slate-800 pb-6">
              <div className="flex items-center justify-between">
                <LevelBadge level={activeLesson.level} size="md" />
                <span className="text-xs text-indigo-400 font-semibold en-ltr">
                  {activeLesson.titleEn}
                </span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
                {activeLesson.titleAr}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300">{activeLesson.summaryAr}</p>

              {/* Formula Badge Card */}
              <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 space-y-1">
                <span className="text-[11px] font-semibold text-indigo-300 flex items-center gap-1">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                  قاعدة التكوين الرياضية (Structure Formula):
                </span>
                <p className="text-sm font-mono font-bold text-white en-ltr bg-slate-950/70 p-2.5 rounded-xl border border-slate-800">
                  {activeLesson.formula}
                </p>
              </div>
            </div>

            {/* Explanation Sections */}
            <div className="space-y-6">
              {activeLesson.sections.map((sec, idx) => (
                <div key={idx} className="space-y-3">
                  <h4 className="text-base font-bold text-indigo-300">{sec.heading}</h4>
                  <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 whitespace-pre-line leading-relaxed">
                    {sec.text}
                  </div>

                  {sec.examples && sec.examples.length > 0 && (
                    <div className="space-y-2 pt-1">
                      <span className="text-xs font-semibold text-slate-400">أمثلة تطبيقية مع الصوت:</span>
                      <div className="grid grid-cols-1 gap-2">
                        {sec.examples.map((ex, exIdx) => (
                          <div
                            key={exIdx}
                            className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/50 flex items-center justify-between gap-3"
                          >
                            <div className="space-y-0.5">
                              <p className="text-sm font-bold text-white en-ltr">{ex.en}</p>
                              <p className="text-xs text-slate-300">{ex.ar}</p>
                            </div>
                            <AudioButton text={ex.en} size="sm" showSlowToggle={true} />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Interactive Check Mini Quiz */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-950/60 via-slate-950 to-purple-950/60 border border-indigo-500/30 space-y-4 pt-6">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-indigo-400" />
                <h4 className="text-base font-bold text-white">تحقق من فهمك للقاعدة (Quick Check)</h4>
              </div>

              <p className="text-sm font-semibold text-slate-200">{activeLesson.quickCheck.question}</p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {activeLesson.quickCheck.options.map((opt, optIdx) => {
                  const isSelected = quizAnswers[activeLesson.id] === optIdx;
                  return (
                    <button
                      key={optIdx}
                      type="button"
                      onClick={() =>
                        handleCheckAnswer(
                          activeLesson.id,
                          optIdx,
                          activeLesson.quickCheck.correctIndex
                        )
                      }
                      className={`p-3 rounded-xl text-center font-bold text-sm en-ltr transition cursor-pointer ${
                        isSelected
                          ? optIdx === activeLesson.quickCheck.correctIndex
                            ? "bg-emerald-600 text-white"
                            : "bg-rose-600 text-white"
                          : "bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700"
                      }`}
                    >
                      {opt}
                    </button>
                  );
                })}
              </div>

              {quizFeedback[activeLesson.id] && (
                <div
                  className={`p-3 rounded-xl text-xs font-bold ${
                    quizFeedback[activeLesson.id] === "correct"
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                  }`}
                >
                  <p>
                    {quizFeedback[activeLesson.id] === "correct" ? "🎉 أحسنت! إجابة صحيحة." : "❌ حاول مرة أخرى!"}
                  </p>
                  <p className="font-normal mt-1 opacity-90">{activeLesson.quickCheck.explanation}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
