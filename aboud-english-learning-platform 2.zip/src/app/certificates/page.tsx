"use client";

import React, { useState, useEffect } from "react";
import { useAuth } from "@/context/AuthContext";
import { LevelBadge } from "@/components/LevelBadge";
import {
  Award,
  Sparkles,
  Printer,
  ShieldCheck,
  Search,
  CheckCircle2,
  Calendar,
  GraduationCap,
  Download,
  Loader2,
} from "lucide-react";

interface CertificateItem {
  id: number;
  certificateNumber: string;
  levelCode: string;
  studentName: string;
  score: number;
  issuedAt: string;
}

export default function CertificatesPage() {
  const { user } = useAuth();
  const [certificates, setCertificates] = useState<CertificateItem[]>([]);
  const [selectedCert, setSelectedCert] = useState<CertificateItem | null>(null);
  const [loading, setLoading] = useState(true);

  // Public search verification state
  const [searchCode, setSearchCode] = useState("");
  const [verifying, setVerifying] = useState(false);
  const [verifiedCert, setVerifiedCert] = useState<CertificateItem | null>(null);
  const [searchError, setSearchError] = useState("");

  useEffect(() => {
    async function fetchCertificates() {
      try {
        const res = await fetch("/api/certificates");
        const data = await res.json();
        if (data.certificates && data.certificates.length > 0) {
          setCertificates(data.certificates);
          setSelectedCert(data.certificates[0]);
        }
      } catch (err) {
        console.error("Fetch certificates failed", err);
      } finally {
        setLoading(false);
      }
    }
    fetchCertificates();
  }, []);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchCode.trim()) return;

    setVerifying(true);
    setSearchError("");
    setVerifiedCert(null);

    try {
      const res = await fetch(`/api/certificates?code=${encodeURIComponent(searchCode.trim())}`);
      const data = await res.json();
      if (res.ok && data.certificate) {
        setVerifiedCert(data.certificate);
        setSelectedCert(data.certificate);
      } else {
        setSearchError("لم يتم العثور على شهادة بهذا الرقم. تأكد من صحة الرمز.");
      }
    } catch {
      setSearchError("حدث خطأ أثناء التحقق");
    } finally {
      setVerifying(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const activeDisplayCert = verifiedCert || selectedCert || (user ? {
    id: 999,
    certificateNumber: `ABOUD-${Date.now().toString().slice(-6)}-${user.currentLevel}`,
    levelCode: user.currentLevel || "A1",
    studentName: user.name || "طالب متميز",
    score: 95,
    issuedAt: new Date().toISOString(),
  } : null);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-semibold">
            <Award className="w-3.5 h-3.5" />
            <span>شهادات الإتمام والتحقق الرسمي</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white">
            شهادات منصة عبود لتعلّم الإنجليزية
          </h1>
          <p className="text-xs sm:text-sm text-slate-300">
            شهادات إتمام رقمية برقم تسلسلي فريد توثّق اجتيازك لمستويات اللغة الإنجليزية واختباراتها التفاعلية.
          </p>
        </div>

        {/* Public Verification Bar */}
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl max-w-2xl mx-auto">
          <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>التحقق من صحة شهادة برقم التسلسل:</span>
          </h3>

          <form onSubmit={handleVerify} className="flex gap-2">
            <input
              type="text"
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              placeholder="مثال: ABOUD-849201-A1"
              className="flex-1 px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white placeholder-slate-500 text-xs focus:outline-none focus:border-indigo-500 en-ltr"
            />
            <button
              type="submit"
              disabled={verifying}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 transition disabled:opacity-50"
            >
              {verifying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              <span>تحقق الآن</span>
            </button>
          </form>

          {searchError && (
            <p className="text-rose-400 text-xs mt-2 text-center">{searchError}</p>
          )}

          {verifiedCert && (
            <div className="mt-3 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs text-center flex items-center justify-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>شهادة موثقة وصحيحة صادرة باسم: <strong>{verifiedCert.studentName}</strong></span>
            </div>
          )}
        </div>

        {/* Certificate Printable Showcase Card */}
        {activeDisplayCert && (
          <div className="space-y-4">
            <div className="flex items-center justify-between max-w-4xl mx-auto">
              <span className="text-xs text-slate-400">معاينة الشهادة الرسمية:</span>
              <button
                onClick={handlePrint}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-xs shadow-lg inline-flex items-center gap-2 transition"
              >
                <Printer className="w-4 h-4" />
                <span>طباعة أو حفظ كملف PDF 📄</span>
              </button>
            </div>

            {/* Official Diploma Certificate Design */}
            <div
              id="certificate-print-area"
              className="p-8 sm:p-14 rounded-3xl bg-slate-900 border-8 border-indigo-950/80 shadow-2xl max-w-4xl mx-auto relative overflow-hidden text-center text-slate-100"
              style={{
                backgroundImage:
                  "radial-gradient(circle at 50% 50%, rgba(99, 102, 241, 0.08) 0%, rgba(15, 23, 42, 1) 100%)",
              }}
            >
              {/* Outer Golden/Indigo Decorative Border Frame */}
              <div className="absolute inset-3 border-2 border-indigo-500/30 rounded-2xl pointer-events-none"></div>

              {/* Platform Header */}
              <div className="flex items-center justify-between mb-8 relative z-10">
                <div className="text-right">
                  <span className="font-extrabold text-base bg-gradient-to-r from-blue-400 to-indigo-300 bg-clip-text text-transparent">
                    منصة عَبّود التعليمية
                  </span>
                  <p className="text-[10px] text-slate-400">ABOUD ENGLISH PLATFORM</p>
                </div>

                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 flex items-center justify-center shadow-xl">
                  <GraduationCap className="w-8 h-8" />
                </div>

                <div className="text-left en-ltr">
                  <span className="text-[11px] font-bold text-indigo-400">CEFR FRAMEWORK</span>
                  <p className="text-[10px] text-slate-400">ACCREDITED CURRICULUM</p>
                </div>
              </div>

              {/* Diploma Title */}
              <div className="space-y-2 relative z-10">
                <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300 bg-clip-text text-transparent font-serif">
                  شهادة إتمام مقرر لغة إنجليزية
                </h2>
                <p className="text-xs sm:text-sm text-indigo-300 tracking-widest font-mono uppercase">
                  CERTIFICATE OF COMPLETION
                </p>
              </div>

              {/* Recipient Name */}
              <div className="my-8 py-4 border-y border-indigo-500/20 max-w-xl mx-auto relative z-10">
                <p className="text-xs text-slate-400 mb-1">تشهد منصة عبود بأن الطالب / الطالبة:</p>
                <h3 className="text-3xl sm:text-4xl font-black text-white font-serif">
                  {activeDisplayCert.studentName}
                </h3>
              </div>

              {/* Achievement Body */}
              <div className="space-y-3 max-w-2xl mx-auto relative z-10 text-xs sm:text-sm text-slate-300 leading-relaxed">
                <p>
                  قد اجتاز بنجاح متطلبات واختبارات المستوى التعليمي:
                </p>
                <div className="inline-flex items-center gap-2 px-5 py-2 rounded-2xl bg-indigo-600/30 border border-indigo-400/40 text-indigo-200 font-bold text-base">
                  <span>المستوى: {activeDisplayCert.levelCode}</span>
                  <span>•</span>
                  <span>الدرجة: {activeDisplayCert.score}%</span>
                </div>
                <p className="text-[11px] text-slate-400 pt-1">
                  شاملاً القواعد، المفردات، الاستماع، النطق، والمحادثات اليومية.
                </p>
              </div>

              {/* Bottom Signatures & Seal */}
              <div className="mt-12 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6 relative z-10 text-xs">
                <div className="text-right">
                  <p className="text-slate-400">تاريخ الإصدار:</p>
                  <p className="font-bold text-white mt-0.5">
                    {new Date(activeDisplayCert.issuedAt).toLocaleDateString("ar-EG")}
                  </p>
                </div>

                {/* Digital Seal */}
                <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500/20 to-yellow-500/20 border-2 border-amber-400/50 flex flex-col items-center justify-center text-amber-300 shadow-lg">
                  <ShieldCheck className="w-6 h-6" />
                  <span className="text-[8px] font-black uppercase mt-0.5">VERIFIED</span>
                </div>

                <div className="text-left en-ltr">
                  <p className="text-slate-400">رمز التحقق التسلسلي:</p>
                  <p className="font-mono font-bold text-indigo-300 mt-0.5">
                    {activeDisplayCert.certificateNumber}
                  </p>
                </div>
              </div>

              {/* Clarification Disclaimer */}
              <p className="text-[10px] text-slate-500 mt-6 relative z-10">
                * ملاحظة: هذه شهادة إتمام إلكترونية صادرة من منصة عبود التعليمية لتوثيق تقدم الطالب واجتيازه للمقررات والاختبارات التفاعلية بنجاح.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
