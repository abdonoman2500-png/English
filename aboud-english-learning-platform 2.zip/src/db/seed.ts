import { db } from "./index";
import { users, levels, units, lessons, vocabulary, conversations, quizzes } from "./schema";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";

export async function seedDatabase() {
  try {
    // Check if levels already exist
    const existingLevels = await db.select().from(levels);
    if (existingLevels.length > 0) {
      return { message: "Database already seeded" };
    }

    // 1. Create Default Users
    const passwordHash = await bcrypt.hash("password123", 10);

    const [adminUser] = await db
      .insert(users)
      .values([
        {
          name: "الأستاذ عبود (المدير)",
          email: "admin@aboud-english.com",
          passwordHash,
          role: "admin",
          currentLevel: "C2",
          xp: 2500,
          streakDays: 45,
        },
        {
          name: "سارة الأحمد (معلمة)",
          email: "teacher@aboud-english.com",
          passwordHash,
          role: "teacher",
          currentLevel: "C1",
          xp: 1800,
          streakDays: 28,
        },
        {
          name: "محمد خالد (طالب نشط)",
          email: "student@aboud-english.com",
          passwordHash,
          role: "student",
          currentLevel: "A1",
          xp: 450,
          streakDays: 7,
        },
      ])
      .returning();

    // 2. Insert Levels
    const levelList = [
      {
        code: "Pre-A1",
        titleAr: "المستوى التمهيدي (من الصفر)",
        titleEn: "Absolute Beginner (Pre-A1)",
        descriptionAr: "الحروف الأبجدية، الأصوات والنطق، الأرقام، والتحيات الأساسية جداً.",
        orderIndex: 1,
        color: "from-sky-500 to-blue-600",
        icon: "Sparkles",
      },
      {
        code: "A1",
        titleAr: "المستوى المبتدئ",
        titleEn: "Beginner (A1)",
        descriptionAr: "تكوين الجمل البسيطة، الضمائر، الأفعال الأساسية، والمحادثات اليومية في المطعم والتعارف.",
        orderIndex: 2,
        color: "from-blue-600 to-indigo-600",
        icon: "BookOpen",
      },
      {
        code: "A2",
        titleAr: "المستوى فوق المبتدئ",
        titleEn: "Elementary (A2)",
        descriptionAr: "الماضي والمستقبل، المقارنة والتفضيل، التعبير عن المشاعر والتسوق والسفر.",
        orderIndex: 3,
        color: "from-indigo-600 to-violet-600",
        icon: "Compass",
      },
      {
        code: "B1",
        titleAr: "المستوى المتوسط",
        titleEn: "Intermediate (B1)",
        descriptionAr: "الأزمنة المركبة، الأفعال المساعدة، المحادثات في العمل، والمقالات القصيرة.",
        orderIndex: 4,
        color: "from-violet-600 to-purple-600",
        icon: "Award",
      },
      {
        code: "B2",
        titleAr: "المستوى فوق المتوسط",
        titleEn: "Upper Intermediate (B2)",
        descriptionAr: "المبني للمجهول، الجمل الشرطية، النقاشات المتقدمة، والمقابلات الوظيفية.",
        orderIndex: 5,
        color: "from-purple-600 to-fuchsia-600",
        icon: "Flame",
      },
      {
        code: "C1",
        titleAr: "المستوى المتقدم",
        titleEn: "Advanced (C1)",
        descriptionAr: "التعبيرات الاصطلاحية (Idioms)، القواعد الأكاديمية، والطلاقة في الحوارات المعقدة.",
        orderIndex: 6,
        color: "from-fuchsia-600 to-pink-600",
        icon: "Crown",
      },
      {
        code: "C2",
        titleAr: "مستوى الإتقان التام",
        titleEn: "Proficiency (C2)",
        descriptionAr: "إتقان كامل للهجات، الصياغات البلاغية، والكتابة الاحترافية والطلاقة الشبيهة بالمتحدث الأصلي.",
        orderIndex: 7,
        color: "from-pink-600 to-rose-600",
        icon: "Trophy",
      },
    ];

    await db.insert(levels).values(levelList);

    // 3. Units
    const unitList = [
      // Pre-A1 Units
      {
        levelCode: "Pre-A1",
        titleAr: "الوحدة 1: الحروف الإنجليزية والأصوات (The Alphabet & Phonics)",
        titleEn: "Unit 1: The English Alphabet & Sounds",
        descriptionAr: "تعلم نطق وكتابة الحروف الـ 26 من A إلى Z مع الأصوات والمقارنة.",
        orderIndex: 1,
        icon: "Type",
      },
      {
        levelCode: "Pre-A1",
        titleAr: "الوحدة 2: الأرقام والألوان والأيام",
        titleEn: "Unit 2: Numbers, Colors & Days",
        descriptionAr: "العد من 1 إلى 100، الألوان الشائعة، وأيام الأسبوع مع النطق.",
        orderIndex: 2,
        icon: "Hash",
      },
      // A1 Units
      {
        levelCode: "A1",
        titleAr: "الوحدة 1: الضمائر وفعل الكينونة (Pronouns & Verb To Be)",
        titleEn: "Unit 1: Pronouns & Verb To Be",
        descriptionAr: "ضمائر الفاعل (I, you, he, she...) وكيف تقول أنا أكون، هو يكون.",
        orderIndex: 1,
        icon: "UserCheck",
      },
      {
        levelCode: "A1",
        titleAr: "الوحدة 2: المضارع البسيط والروتين اليومي (Present Simple)",
        titleEn: "Unit 2: Present Simple & Daily Routine",
        descriptionAr: "التحدث عن أفعالك اليومية والعادات وتكوين جمل الإثبات والنفي والسؤال.",
        orderIndex: 2,
        icon: "Clock",
      },
      {
        levelCode: "A1",
        titleAr: "الوحدة 3: التعارف والمحادثات في المطعم",
        titleEn: "Unit 3: Greetings & Restaurant English",
        descriptionAr: "كيف تقدم نفسك وتطلب الطعام في المطعم باللغة الإنجليزية.",
        orderIndex: 3,
        icon: "Coffee",
      },
      // A2 Units
      {
        levelCode: "A2",
        titleAr: "الوحدة 1: الماضي البسيط (Past Simple Tense)",
        titleEn: "Unit 1: Past Simple Tense",
        descriptionAr: "الأفعال المنتظمة والشاذة وكيف تحكي ما حدث معك في الماضي.",
        orderIndex: 1,
        icon: "History",
      },
      {
        levelCode: "A2",
        titleAr: "الوحدة 2: المستقبل وخطط الغد (Future with Will & Going to)",
        titleEn: "Unit 2: Future Plans (Will / Going to)",
        descriptionAr: "التعبير عن الخطط والقرارات والتوقعات المستقبلية.",
        orderIndex: 2,
        icon: "Calendar",
      },
      // B1 Units
      {
        levelCode: "B1",
        titleAr: "الوحدة 1: المضارع التام (Present Perfect Tense)",
        titleEn: "Unit 1: Present Perfect Tense",
        descriptionAr: "ربط الماضي بالحاضر، استخدام Since, For, Already, Yet.",
        orderIndex: 1,
        icon: "Zap",
      },
      {
        levelCode: "B1",
        titleAr: "الوحدة 2: الأفعال المساعدة (Modal Verbs: Can, Must, Should)",
        titleEn: "Unit 2: Modal Verbs (Can, Must, Should)",
        descriptionAr: "التعبير عن الإلزام والنصيحة والقدرة والاحتمال.",
        orderIndex: 2,
        icon: "ShieldAlert",
      },
      // B2 Units
      {
        levelCode: "B2",
        titleAr: "الوحدة 1: الجمل الشرطية (Conditionals: 0, 1, 2, 3)",
        titleEn: "Unit 1: Conditional Clauses (If Clauses)",
        descriptionAr: "قواعد If الشرطية للتعبير عن الحقائق، والافتراضات، والندم.",
        orderIndex: 1,
        icon: "GitBranch",
      },
      {
        levelCode: "B2",
        titleAr: "الوحدة 2: المبني للمجهول (Passive Voice)",
        titleEn: "Unit 2: Passive Voice in All Tenses",
        descriptionAr: "متى وكيف نحول الجملة إلى المبني للمجهول في مختلف الأزمنة.",
        orderIndex: 2,
        icon: "Layers",
      },
      // C1 Units
      {
        levelCode: "C1",
        titleAr: "الوحدة 1: التعبيرات الاصطلاحية والأمثال (Idioms & Proverbs)",
        titleEn: "Unit 1: Advanced Idioms & Expressions",
        descriptionAr: "التحدث بأسلوب المتحدثين الأصليين واستخدام التعبيرات البلاغية الشائعة.",
        orderIndex: 1,
        icon: "Sparkles",
      },
      // C2 Units
      {
        levelCode: "C2",
        titleAr: "الوحدة 1: البلاغة والكتابة الأكاديمية المتقدمة",
        titleEn: "Unit 1: Advanced Nuances & Stylistics",
        descriptionAr: "الفروق الدقيقة بين المترادفات والأسلوب الإقناعي والكتابة المتقنة.",
        orderIndex: 1,
        icon: "Feather",
      },
    ];

    const insertedUnits = await db.insert(units).values(unitList).returning();
    const unit1PreA1 = insertedUnits[0]?.id;
    const unit2PreA1 = insertedUnits[1]?.id;
    const unit1A1 = insertedUnits[2]?.id;
    const unit2A1 = insertedUnits[3]?.id;
    const unit1A2 = insertedUnits[5]?.id;
    const unit1B1 = insertedUnits[7]?.id;
    const unit1B2 = insertedUnits[9]?.id;

    // 4. Lessons
    const lessonsList = [
      // Pre-A1: Alphabet Complete Lesson
      {
        unitId: unit1PreA1,
        levelCode: "Pre-A1",
        category: "alphabet",
        titleAr: "دليل الحروف الإنجليزية الـ 26 ونطقها",
        titleEn: "The 26 English Letters & Pronunciation",
        descriptionAr: "شرح شامل لجميع الحروف الكبيرة (Capital) والصغيرة (Small) مع أصواتها وأمثلة مصورة.",
        orderIndex: 1,
        durationMinutes: 15,
        xpReward: 30,
        contentJson: JSON.stringify({
          summary: "في اللغة الإنجليزية 26 حرفاً، تنقسم إلى حروف ساكنة (Consonants) وحروف متحركة أو علة (Vowels: A, E, I, O, U).",
          sections: [
            {
              heading: "الحروف المتحركة الأساسية (Vowels)",
              text: "الحروف المتحركة هي: A, E, I, O, U. هي بمثابة حركات التشكيل في اللغة العربية (الفتحة والضمة والكسرة). لا تكاد تخلو كلمة إنجليزية من حرف علة.",
              tips: "احفظها كوجه مبتسم: O للوجه، E و I للعيون، U للفم، و A للأنف!",
            },
            {
              heading: "الأصوات المركبة الهامة (Digraphs)",
              text: "عند دمج حرفين معاً ينتج صوت جديد:\n• SH = ش (مثل: Ship = سفينة)\n• CH = تش (مثل: Chair = كرسي)\n• TH = ث أو ذ (مثل: Think = يفكّر / This = هذا)\n• PH = ف (مثل: Photo = صورة)\n• WH = و (مثل: What = ماذا)",
            },
            {
              heading: "الحروف الصامتة (Silent Letters)",
              text: "بعض الحروف تُكتب ولا تُنطق في مواضع محددة:\n• حرف K صامت قبل N: مثل Know (يعرف), Knee (ركبة)\n• حرف W صامت قبل R: مثل Write (يكتب), Wrong (خطأ)\n• حرف B صامت بعد M في نهاية الكلمة: مثل Comb (مشط), Climb (يتسلق)",
            },
          ],
          interactiveTable: [
            { letter: "Aa", sound: "/æ/ - /eɪ/", example: "Apple (تفاحة)", audio: "Apple" },
            { letter: "Bb", sound: "/b/", example: "Book (كتاب)", audio: "Book" },
            { letter: "Cc", sound: "/k/ or /s/", example: "Cat (قطة) / City (مدينة)", audio: "Cat" },
            { letter: "Dd", sound: "/d/", example: "Door (باب)", audio: "Door" },
            { letter: "Ee", sound: "/e/ - /iː/", example: "Elephant (فيل)", audio: "Elephant" },
            { letter: "Ff", sound: "/f/", example: "Fish (سمكة)", audio: "Fish" },
            { letter: "Gg", sound: "/ɡ/ or /dʒ/", example: "Good (جيد) / Giraffe (زرافة)", audio: "Good" },
            { letter: "Hh", sound: "/h/", example: "House (منزل)", audio: "House" },
            { letter: "Ii", sound: "/ɪ/ - /aɪ/", example: "Ice (ثلج)", audio: "Ice" },
            { letter: "Jj", sound: "/dʒ/", example: "Juice (عصير)", audio: "Juice" },
            { letter: "Kk", sound: "/k/", example: "King (ملك)", audio: "King" },
            { letter: "Ll", sound: "/l/", example: "Lion (أسد)", audio: "Lion" },
            { letter: "Mm", sound: "/m/", example: "Moon (قمر)", audio: "Moon" },
            { letter: "Nn", sound: "/n/", example: "Night (ليل)", audio: "Night" },
            { letter: "Oo", sound: "/ɒ/ - /oʊ/", example: "Orange (برتقال)", audio: "Orange" },
            { letter: "Pp", sound: "/p/", example: "Pen (قلم)", audio: "Pen" },
            { letter: "Qq", sound: "/kw/", example: "Queen (ملكة)", audio: "Queen" },
            { letter: "Rr", sound: "/r/", example: "River (نهر)", audio: "River" },
            { letter: "Ss", sound: "/s/", example: "Sun (شمس)", audio: "Sun" },
            { letter: "Tt", sound: "/t/", example: "Tree (شجرة)", audio: "Tree" },
            { letter: "Uu", sound: "/ʌ/ - /juː/", example: "Umbrella (مظلة)", audio: "Umbrella" },
            { letter: "Vv", sound: "/v/", example: "Voice (صوت)", audio: "Voice" },
            { letter: "Ww", sound: "/w/", example: "Water (ماء)", audio: "Water" },
            { letter: "Xx", sound: "/ks/", example: "Box (صندوق)", audio: "Box" },
            { letter: "Yy", sound: "/j/", example: "Yellow (أصفر)", audio: "Yellow" },
            { letter: "Zz", sound: "/z/", example: "Zoo (حديقة حيوان)", audio: "Zoo" },
          ],
        }),
      },
      // A1: Pronouns & Verb To Be
      {
        unitId: unit1A1,
        levelCode: "A1",
        category: "grammar",
        titleAr: "الضمائر الشخصية وفعل الكينونة (Verb to Be)",
        titleEn: "Subject Pronouns & Verb to Be (am, is, are)",
        descriptionAr: "حجر الأساس في قواعد الإنجليزية: I am, You are, He is, She is, It is, We are, They are وكيفية النفي والسؤال.",
        orderIndex: 1,
        durationMinutes: 12,
        xpReward: 30,
        contentJson: JSON.stringify({
          summary: "فعل الكينونة (Verb to Be) هو أهم فعل في الإنجليزية، ويعني (يكون)، ويستخدم لوصف الأشخاص، المهن، الصفات، والأماكن.",
          sections: [
            {
              heading: "1. جدول ضمائر الفاعل وتصريف فعل الكينونة",
              text: "• I + am = I am (أنا أكون) -> الاختصار: I'm\n• He + is = He is (هو يكون) -> الاختصار: He's\n• She + is = She is (هي تكون) -> الاختصار: She's\n• It + is = It is (هو/هي لغير العاقل) -> الاختصار: It's\n• You + are = You are (أنتَ / أنتم) -> الاختصار: You're\n• We + are = We are (نحن نكون) -> الاختصار: We're\n• They + are = They are (هم يكونون) -> الاختصار: They're",
            },
            {
              heading: "2. أمثلة توضيحية مع الترجمة والصوت",
              text: "• I am a student. (أنا طالب)\n• She is happy. (هي سعيدة)\n• He is in Riyadh. (هو في الرياض)\n• They are teachers. (هم معلمون)\n• It is cold today. (الجو بارد اليوم)",
            },
            {
              heading: "3. صيغة النفي (Negative)",
              text: "للنفي نضيف كلمة not بعد الفعل مباشرة:\n• I am not tired. (أنا لست متعباً)\n• He is not (isn't) hungry. (هو ليس جائعاً)\n• We are not (aren't) late. (نحن لسنا متأخرين)",
            },
            {
              heading: "4. تكوين السؤال (Yes / No Questions)",
              text: "نعكس مكان الفاعل والفعل:\n• Are you ready? -> Yes, I am. / No, I am not.\n• Is she doctor? -> Yes, she is. / No, she isn't.",
            },
          ],
          quickQuiz: [
            {
              question: "اختر الكلمة الصحيحة: She ___ a teacher.",
              options: ["am", "is", "are"],
              correctIndex: 1,
              explanation: "الضمير She يأخذ الفعل is دائماً في المضارع.",
            },
            {
              question: "اختر النفي الصحيح للجملة: They are ready.",
              options: ["They not are ready.", "They are not ready.", "They isn't ready."],
              correctIndex: 1,
              explanation: "نضع not بعد فعل are فتصبح They are not (aren't) ready.",
            },
          ],
        }),
      },
      // A1: Present Simple
      {
        unitId: unit2A1,
        levelCode: "A1",
        category: "grammar",
        titleAr: "زمن المضارع البسيط (Present Simple Tense)",
        titleEn: "Present Simple: Habits & Facts",
        descriptionAr: "تعلم التعبير عن عاداتك اليومية وحقائقك، قاعدة إضافة S مع المفرد، والنفي بـ don't و doesn't.",
        orderIndex: 2,
        durationMinutes: 15,
        xpReward: 35,
        contentJson: JSON.stringify({
          summary: "المضارع البسيط يعبر عن: 1) العادات والروتين اليومي 2) الحقائق العلمية العامة.",
          sections: [
            {
              heading: "قاعدة التكوين (Structure)",
              text: "• مع (I / You / We / They): نضع الفعل في المصدر (بدون أي إضافة)\n  مثال: I drink water every morning. (أنا أشرب الماء كل صباح)\n• مع (He / She / It / الاسم المفرد): نضيف s أو es لنهاية الفعل!\n  مثال: He drinks coffee. / She watches TV.",
            },
            {
              heading: "النفي (Negative)",
              text: "• مع الجمع (I/You/We/They): نستخدم don't + الفعل بالمصدر\n  مثال: I don't smoke. (أنا لا أدخن)\n• مع المفرد (He/She/It): نستخدم doesn't + الفعل بالمصدر (ونحذف s)\n  مثال: He doesn't drink tea. (هو لا يشرب الشاي)",
            },
            {
              heading: "الكلمات الدالة (Keywords / Adverbs of Frequency)",
              text: "Always (دائماً), Usually (عادةً), Often (غالباً), Sometimes (أحياناً), Never (أبداً), Every day (كل يوم).",
            },
          ],
        }),
      },
      // A2: Past Simple
      {
        unitId: unit1A2,
        levelCode: "A2",
        category: "grammar",
        titleAr: "زمن الماضي البسيط (Past Simple Tense)",
        titleEn: "Past Simple: Regular & Irregular Verbs",
        descriptionAr: "شرح تصريف الأفعال المنتظمة بـ ed والأفعال الشاذة الشائعة مثل went, saw, bought, played.",
        orderIndex: 1,
        durationMinutes: 15,
        xpReward: 35,
        contentJson: JSON.stringify({
          summary: "الماضي البسيط يُستخدم للأحداث التي بدأت وانتهت في وقت محدد في الماضي.",
          sections: [
            {
              heading: "1. الأفعال المنتظمة (Regular Verbs)",
              text: "نضيف ed لنهاية الفعل:\n• Play -> Played (لعب)\n• Watch -> Watched (شاهد)\n• Work -> Worked (عمل)\n• Study -> Studied (درس)",
            },
            {
              heading: "2. الأفعال غير المنتظمة (Irregular Verbs)",
              text: "أفعال شاذة يتغير شكلها ويجب حفظها:\n• Go -> Went (ذهب)\n• See -> Saw (رأى)\n• Have -> Had (امتلك/تناول)\n• Buy -> Bought (اشترى)\n• Eat -> Ate (أكل)",
            },
            {
              heading: "3. النفي والسؤال في الماضي",
              text: "نستخدم didn't للنفي + الفعل بالمصدر:\n• I didn't see him. (لم أره)\n• Did you visit London? -> Yes, I did.",
            },
          ],
        }),
      },
      // B1: Present Perfect
      {
        unitId: unit1B1,
        levelCode: "B1",
        category: "grammar",
        titleAr: "زمن المضارع التام (Present Perfect Tense)",
        titleEn: "Present Perfect: Have / Has + V3",
        descriptionAr: "متى نستخدم Have/Has مع التصريف الثالث؟ الفارق بين الماضي البسيط والمضارع التام مع For و Since.",
        orderIndex: 1,
        durationMinutes: 15,
        xpReward: 40,
        contentJson: JSON.stringify({
          summary: "المضارع التام يعبر عن تجارب وخبرات حياتية حدثت في الماضي ولها أثر في الحاضر، أو أحداث بدأت في الماضي ومستمرة.",
          sections: [
            {
              heading: "قاعدة التكوين (Subject + have/has + V3)",
              text: "• I / You / We / They + have + Past Participle (V3)\n• He / She / It + has + Past Participle (V3)\n\nأمثلة:\n• I have lived in Riyadh for 5 years. (عشت في الرياض لمدة 5 سنوات وما زلت)\n• She has already finished her work. (لقد أنهت عملها بالفعل)",
            },
          ],
        }),
      },
      // B2: Conditionals
      {
        unitId: unit1B2,
        levelCode: "B2",
        category: "grammar",
        titleAr: "الجمل الشرطية الأربعة (Conditionals 0, 1, 2, 3)",
        titleEn: "All Conditional Forms (Zero, First, Second, Third)",
        descriptionAr: "شرح شامل لقواعد If الشرطية للتعبير عن الحقائق، التوقعات المستقبلية، الفرضيات الخيالية، والندم على الماضي.",
        orderIndex: 1,
        durationMinutes: 20,
        xpReward: 45,
        contentJson: JSON.stringify({
          summary: "الجمل الشرطية تتكون من جملة الشرط (If clause) وجملة جواب الشرط (Main clause).",
          sections: [
            {
              heading: "Zero Conditional (الحقائق العلمية)",
              text: "If + Present Simple, Present Simple\nمثال: If you heat ice, it melts. (إذا سخنت الثلج فإنه يذوب)",
            },
            {
              heading: "First Conditional (إمكانية واقعية في المستقبل)",
              text: "If + Present Simple, will + verb\nمثال: If it rains tomorrow, we will stay at home. (إذا أمطرت غداً، سنبقى في المنزل)",
            },
            {
              heading: "Second Conditional (افتراض خيالي غير واقعي في الحاضر)",
              text: "If + Past Simple, would + verb\nمثال: If I had a million dollars, I would travel the world. (لو كان معي مليون دولار لسافرت حول العالم)",
            },
            {
              heading: "Third Conditional (ندم على شيء حدث في الماضي)",
              text: "If + had + V3, would have + V3\nمثال: If I had studied harder, I would have passed the exam. (لو أنني درست بجد أكبر لاجتزت الاختبار)",
            },
          ],
        }),
      },
    ];

    await db.insert(lessons).values(lessonsList);

    // 5. Rich Vocabulary
    const vocabData = [
      // Basics (Pre-A1 / A1)
      {
        word: "Hello",
        phonetic: "/həˈloʊ/",
        partOfSpeech: "phrase",
        translationAr: "مرحباً / أهلاً",
        levelCode: "Pre-A1",
        category: "basics",
        exampleEn: "Hello! Nice to meet you.",
        exampleAr: "مرحباً! سررت بلقائك.",
      },
      {
        word: "Thank you",
        phonetic: "/θæŋk juː/",
        partOfSpeech: "phrase",
        translationAr: "شكراً لك",
        levelCode: "Pre-A1",
        category: "basics",
        exampleEn: "Thank you very much for your help.",
        exampleAr: "شكراً جزيلاً على مساعدتك.",
      },
      {
        word: "Please",
        phonetic: "/pliːz/",
        partOfSpeech: "adverb",
        translationAr: "من فضلك / رجاءً",
        levelCode: "Pre-A1",
        category: "basics",
        exampleEn: "Can I have some water, please?",
        exampleAr: "هل يمكنني الحصول على بعض الماء من فضلك؟",
      },
      {
        word: "Goodbye",
        phonetic: "/ɡʊdˈbaɪ/",
        partOfSpeech: "phrase",
        translationAr: "مع السلامة / وداعاً",
        levelCode: "Pre-A1",
        category: "basics",
        exampleEn: "Goodbye, see you tomorrow!",
        exampleAr: "مع السلامة، أراك غداً!",
      },
      {
        word: "Family",
        phonetic: "/ˈfæm.əl.i/",
        partOfSpeech: "noun",
        translationAr: "عائلة / أسرة",
        levelCode: "A1",
        category: "family",
        exampleEn: "I love spending time with my family.",
        exampleAr: "أحب قضاء الوقت مع عائلتي.",
      },
      {
        word: "Father",
        phonetic: "/ˈfɑː.ðər/",
        partOfSpeech: "noun",
        translationAr: "أب / والد",
        levelCode: "A1",
        category: "family",
        exampleEn: "My father is an engineer.",
        exampleAr: "والدي مهندس.",
      },
      {
        word: "Mother",
        phonetic: "/ˈmʌð.ər/",
        partOfSpeech: "noun",
        translationAr: "أم / والدة",
        levelCode: "A1",
        category: "family",
        exampleEn: "Her mother cooks delicious food.",
        exampleAr: "والدتها تطبخ طعاماً لذيذاً.",
      },
      {
        word: "Breakfast",
        phonetic: "/ˈbrek.fəst/",
        partOfSpeech: "noun",
        translationAr: "وجبة الإفطار",
        levelCode: "A1",
        category: "food",
        exampleEn: "I usually eat eggs for breakfast.",
        exampleAr: "عادةً ما أتناول البيض في الإفطار.",
      },
      {
        word: "Delicious",
        phonetic: "/dɪˈlɪʃ.əs/",
        partOfSpeech: "adjective",
        translationAr: "لذيذ / شهي",
        levelCode: "A1",
        category: "food",
        exampleEn: "This Arabic coffee is delicious.",
        exampleAr: "هذه القهوة العربية لذيذة.",
      },
      // Travel & Directions (A2)
      {
        word: "Airport",
        phonetic: "/ˈeə.pɔːt/",
        partOfSpeech: "noun",
        translationAr: "مطار",
        levelCode: "A2",
        category: "travel",
        exampleEn: "We need to arrive at the airport two hours early.",
        exampleAr: "علينا الوصول إلى المطار قبل ساعتين.",
      },
      {
        word: "Passport",
        phonetic: "/ˈpɑːs.pɔːt/",
        partOfSpeech: "noun",
        translationAr: "جواز سفر",
        levelCode: "A2",
        category: "travel",
        exampleEn: "Keep your passport in a safe place.",
        exampleAr: "احتفظ بجواز سفرك في مكان آمن.",
      },
      {
        word: "Reservation",
        phonetic: "/ˌrez.əˈveɪ.ʃən/",
        partOfSpeech: "noun",
        translationAr: "حجز (فندق أو طيران)",
        levelCode: "A2",
        category: "travel",
        exampleEn: "I have a reservation under the name Aboud.",
        exampleAr: "لدي حجز باسم عبود.",
      },
      // Business & Work (B1 / B2)
      {
        word: "Opportunity",
        phonetic: "/ˌɒp.əˈtʃuː.nə.ti/",
        partOfSpeech: "noun",
        translationAr: "فرصة سانحة",
        levelCode: "B1",
        category: "business",
        exampleEn: "This job is a great opportunity to learn new skills.",
        exampleAr: "هذه الوظيفة فرصة رائعة لتعلم مهارات جديدة.",
      },
      {
        word: "Achieve",
        phonetic: "/əˈtʃiːv/",
        partOfSpeech: "verb",
        translationAr: "يحقق / ينجز",
        levelCode: "B1",
        category: "business",
        exampleEn: "With practice, you will achieve your English goals.",
        exampleAr: "مع الممارسة، ستحقق أهدافك في اللغة الإنجليزية.",
      },
      {
        word: "Negotiate",
        phonetic: "/nəˈɡoʊ.ʃi.eɪt/",
        partOfSpeech: "verb",
        translationAr: "يتفاوض / يناقش شروطاً",
        levelCode: "B2",
        category: "business",
        exampleEn: "They negotiated a win-win contract.",
        exampleAr: "تفاوضوا على عقد يحقق مصلحة الطرفين.",
      },
      {
        word: "Proficient",
        phonetic: "/prəˈfɪʃ.ənt/",
        partOfSpeech: "adjective",
        translationAr: "بارع / متقن / كفء",
        levelCode: "B2",
        category: "education",
        exampleEn: "He is proficient in English and Arabic.",
        exampleAr: "هو بارع ومتقن للغتين الإنجليزية والعربية.",
      },
      // Idioms & Advanced (C1 / C2)
      {
        word: "Piece of cake",
        phonetic: "/piːs əv keɪk/",
        partOfSpeech: "idiom",
        translationAr: "سهل جداً / في غاية السهولة (مثل شربة ماء)",
        levelCode: "C1",
        category: "idioms",
        exampleEn: "Don't worry about the test, it was a piece of cake!",
        exampleAr: "لا تقلق بشأن الاختبار، لقد كان في غاية السهولة!",
      },
      {
        word: "Break the ice",
        phonetic: "/breɪk ðiː aɪs/",
        partOfSpeech: "idiom",
        translationAr: "يكسر الجمود / يبدأ الحديث لإزالة التوتر",
        levelCode: "C1",
        category: "idioms",
        exampleEn: "He told a funny joke to break the ice in the meeting.",
        exampleAr: "ألقى مزحة لطيفة لكسر الجمود في الاجتماع.",
      },
      {
        word: "Meticulous",
        phonetic: "/məˈtɪk.jə.ləs/",
        partOfSpeech: "adjective",
        translationAr: "دقيق للغاية / شديد العناية بالتفاصيل",
        levelCode: "C2",
        category: "academic",
        exampleEn: "Her research was meticulous and thorough.",
        exampleAr: "كان بحثها دقيقاً للغاية وشاملاً.",
      },
      {
        word: "Ubiquitous",
        phonetic: "/juːˈbɪk.wɪ.təs/",
        partOfSpeech: "adjective",
        translationAr: "واسع الانتشار / موجود في كل مكان",
        levelCode: "C2",
        category: "academic",
        exampleEn: "Smartphones have become ubiquitous in modern life.",
        exampleAr: "أصبحت الهواتف الذكية واسعة الانتشار وموجودة في كل مكان في الحياة المعاصرة.",
      },
    ];

    await db.insert(vocabulary).values(vocabData);

    // 6. Interactive Conversations
    const conversationData = [
      {
        titleAr: "محادثة في المطار (عند شباك التذاكر والجوازات)",
        titleEn: "At the Airport Check-in Desk",
        scenario: "Airport",
        levelCode: "A2",
        grammarNotesAr: "لاحظ استخدام صيغة الأدب: May I see... و I would like to...",
        orderIndex: 1,
        dialogueJson: JSON.stringify([
          {
            speaker: "Agent (الموظف)",
            en: "Good morning! Welcome to Emirates Airlines. May I have your passport and ticket, please?",
            ar: "صباح الخير! مرحباً بك في طيران الإمارات. هل يمكنني الحصول على جواز سفرك وتذكرتك من فضلك؟",
          },
          {
            speaker: "Passenger (المسافر)",
            en: "Good morning. Here you go.",
            ar: "صباح الخير. تفضل، ها هما.",
          },
          {
            speaker: "Agent (الموظف)",
            en: "Thank you. Do you have any bags to check in?",
            ar: "شكراً لك. هل لديك أي حقائب لشحنها؟",
          },
          {
            speaker: "Passenger (المسافر)",
            en: "Yes, I have one suitcase and this small backpack as carry-on.",
            ar: "نعم، لدي حقيبة سفر واحدة وهذه الحقيبة الصغيرة المحمولة على الظهر.",
          },
          {
            speaker: "Agent (الموظف)",
            en: "Great. Would you prefer a window seat or an aisle seat?",
            ar: "رائع. هل تفضل مقعداً بجانب النافذة أم مقعداً بجانب الممر؟",
          },
          {
            speaker: "Passenger (المسافر)",
            en: "A window seat, please.",
            ar: "مقعد بجانب النافذة من فضلك.",
          },
          {
            speaker: "Agent (الموظف)",
            en: "Here is your boarding pass. Gate 14. Boarding starts at 10:30 AM. Have a wonderful flight!",
            ar: "إليك بطاقة الصعود للطائرة. البوابة 14. يبدأ الصعود عند 10:30 صباحاً. رحلة سعيدة!",
          },
        ]),
      },
      {
        titleAr: "طلب الطعام في المطعم (Ordering at a Restaurant)",
        titleEn: "Ordering Food at a Restaurant",
        scenario: "Restaurant",
        levelCode: "A1",
        grammarNotesAr: "تعلّم التعبير عن الرغبة باستخدام I'd like أو Could I have...",
        orderIndex: 2,
        dialogueJson: JSON.stringify([
          {
            speaker: "Waiter (النوادل)",
            en: "Hello, table for two? Right this way, please.",
            ar: "مرحباً، طاولة لشخصين؟ تفضلا من هذا الاتجاه رجاءً.",
          },
          {
            speaker: "Customer (الزبون)",
            en: "Thank you. Could we see the menu, please?",
            ar: "شكراً لك. هل يمكننا رؤية قائمة الطعام من فضلك؟",
          },
          {
            speaker: "Waiter (النوادل)",
            en: "Of course! What would you like to drink to start with?",
            ar: "بالتأكيد! ماذا تحب أن تشرب في البداية؟",
          },
          {
            speaker: "Customer (الزبون)",
            en: "I'd like a bottle of mineral water and fresh orange juice.",
            ar: "أرغب في زجاجة ماء معدني وعصير برتقال طازج.",
          },
          {
            speaker: "Customer (الزبون)",
            en: "And for the main course, I will have the grilled chicken with salad.",
            ar: "وبالنسبة للوجبة الرئيسية، سآخذ الدجاج المشوي مع السلطة.",
          },
          {
            speaker: "Waiter (النوادل)",
            en: "Excellent choice! It will be ready in 15 minutes.",
            ar: "اختيار ممتاز! سيكون جاهزاً خلال 15 دقيقة.",
          },
        ]),
      },
      {
        titleAr: "مقابلة عمل ناجحة (Job Interview)",
        titleEn: "Professional Job Interview",
        scenario: "Job Interview",
        levelCode: "B2",
        grammarNotesAr: "التركيز على لغة التعبير عن الخبرات والإنجازات الشخصية باللغة المهنية.",
        orderIndex: 3,
        dialogueJson: JSON.stringify([
          {
            speaker: "Interviewer (المقابل)",
            en: "Good afternoon, Aboud. Thank you for joining us. Can you tell me a little about yourself?",
            ar: "مساء الخير عبود. شكراً لانضمامك إلينا. هل يمكنك إخباري بنبذة عن نفسك؟",
          },
          {
            speaker: "Applicant (المتقدم)",
            en: "Good afternoon. I am a software engineer with over 4 years of experience building modern web applications.",
            ar: "مساء الخير. أنا مهندس برمجيات ولدي أكثر من 4 سنوات من الخبرة في بناء تطبيقات الويب الحديثة.",
          },
          {
            speaker: "Interviewer (المقابل)",
            en: "Impressive! Why are you interested in working with our company?",
            ar: "مبهر! لماذا أنت مهتم بالعمل في شركتنا تحديداً؟",
          },
          {
            speaker: "Applicant (المتقدم)",
            en: "I admire your innovative culture and focus on artificial intelligence. I believe my skills can help you achieve your roadmap.",
            ar: "أنا معجب بثقافة الابتكار لديكم والتركيز على الذكاء الاصطناعي. وأعتقد أن مهاراتي يمكن أن تساعدكم في تحقيق أهدافكم.",
          },
        ]),
      },
    ];

    await db.insert(conversations).values(conversationData);

    // 7. Comprehensive Placement Test & Quizzes
    const placementQuestions = [
      {
        id: 1,
        type: "multiple_choice",
        level: "Pre-A1",
        promptEn: "What is the capital letter of 'b'?",
        promptAr: "ما هو الحرف الكبير المطابق للحرف الصغير 'b'؟",
        options: ["D", "B", "P", "R"],
        correctIndex: 1,
        explanationAr: "الحرف الكبير للحرف b هو B. انتبه لعدم الخلط بين B و D.",
      },
      {
        id: 2,
        type: "multiple_choice",
        level: "A1",
        promptEn: "Choose the correct sentence:",
        promptAr: "اختر الجملة القواعدية الصحيحة:",
        options: ["He are a doctor.", "He is a doctor.", "He am a doctor.", "He be a doctor."],
        correctIndex: 1,
        explanationAr: "الضمير He (هو) يأخذ فعل الكينونة is في المضارع: He is a doctor.",
      },
      {
        id: 3,
        type: "fill_blank",
        level: "A1",
        promptEn: "I usually _____ coffee in the morning.",
        promptAr: "أنا عادةً _____ القهوة في الصباح.",
        options: ["drinks", "drink", "drinking", "drank"],
        correctIndex: 1,
        explanationAr: "مع الضمير I في المضارع البسيط نستخدم الفعل في المصدر بدون إضافة: I drink.",
      },
      {
        id: 4,
        type: "multiple_choice",
        level: "A1",
        promptEn: "Which word means 'كتاب' in English?",
        promptAr: "ما الكلمة الإنجليزية التي تعني 'كتاب'؟",
        options: ["Pen", "Door", "Book", "Desk"],
        correctIndex: 2,
        explanationAr: "Book تعني كتاب. Pen تعني قلم، Door يعني باب، Desk يعني مكتب.",
      },
      {
        id: 5,
        type: "true_false",
        level: "A2",
        promptEn: "'Yesterday, she went to the market.' Is this sentence grammatically correct?",
        promptAr: "هل الجملة 'Yesterday, she went to the market' صحيحة قواعدياً؟",
        options: ["True (صح)", "False (خطأ)"],
        correctIndex: 0,
        explanationAr: "صحيحة تماماً لأن went هو التصريف الماضي المنتظم للفعل go مع كلمة Yesterday الدالة على الماضي.",
      },
      {
        id: 6,
        type: "multiple_choice",
        level: "A2",
        promptEn: "Mount Everest is ______ mountain in the world.",
        promptAr: "جبل إيفرست هو الجبل _____ في العالم.",
        options: ["the higher", "the highest", "higher than", "highest"],
        correctIndex: 1,
        explanationAr: "في صيغة التفضيل العليا (Superlative) نستخدم the + الصفة + est: the highest.",
      },
      {
        id: 7,
        type: "multiple_choice",
        level: "B1",
        promptEn: "I have lived in this city ______ 2018.",
        promptAr: "عشت في هذه المدينة ______ عام 2018.",
        options: ["for", "since", "during", "ago"],
        correctIndex: 1,
        explanationAr: "نستخدم since عند ذكر نقطة بداية محددة للزمن (سنة، شهر، يوم محدد)، بينما نستخدم for للمدة الإجمالية.",
      },
      {
        id: 8,
        type: "multiple_choice",
        level: "B1",
        promptEn: "You ______ stop when the traffic light turns red.",
        promptAr: "يجب عليك ______ التوقف عندما تتحول إشارة المرور للأحمر.",
        options: ["might", "must", "could", "would"],
        correctIndex: 1,
        explanationAr: "نستخدم must للتعبير عن الإلزام القانوني أو الضرورة القاطعة.",
      },
      {
        id: 9,
        type: "multiple_choice",
        level: "B2",
        promptEn: "If I ______ more time, I would learn Spanish.",
        promptAr: "لو كان لدي وقت أطول، لتعلّمت اللغة الإسبانية.",
        options: ["have", "had", "will have", "would have"],
        correctIndex: 1,
        explanationAr: "هذه الحالة الشرطية الثانية (Second Conditional): If + Past Simple (had), would + infinitive.",
      },
      {
        id: 10,
        type: "multiple_choice",
        level: "B2",
        promptEn: "The new bridge ______ by next December.",
        promptAr: "الجسر الجديد ______ بحلول ديسمبر القادم.",
        options: ["will build", "will be built", "is building", "builds"],
        correctIndex: 1,
        explanationAr: "صيغة مبني للمجهول في المستقبل (Future Passive): will be built.",
      },
      {
        id: 11,
        type: "multiple_choice",
        level: "C1",
        promptEn: "What does the idiom 'once in a blue moon' mean?",
        promptAr: "ما معنى التعبير الاصطلاحي 'once in a blue moon'؟",
        options: ["Every night", "Very rarely", "Always", "On full moon only"],
        correctIndex: 1,
        explanationAr: "'Once in a blue moon' تعني نادراً جداً أو على فترات متباعدة للغاية.",
      },
      {
        id: 12,
        type: "multiple_choice",
        level: "C1",
        promptEn: "Had I known about the meeting, I ______ attended.",
        promptAr: "لو كنت على علم بالاجتماع، لكنت قد حضرت.",
        options: ["would have", "will have", "had", "would"],
        correctIndex: 0,
        explanationAr: "صيغة التقديم والتأخير (Inversion) للحالة الشرطية الثالثة: Had I known = If I had known ... would have attended.",
      },
    ];

    await db.insert(quizzes).values([
      {
        titleAr: "اختبار تحديد المستوى الشامل (Placement Test)",
        titleEn: "Comprehensive CEFR Placement Test",
        levelCode: "Pre-A1",
        category: "placement",
        passScore: 60,
        timeLimitMinutes: 20,
        xpReward: 100,
        questionsJson: JSON.stringify(placementQuestions),
      },
      {
        titleAr: "اختبار الحروف والأصوات للمبتدئين",
        titleEn: "Alphabet & Phonics Quiz",
        levelCode: "Pre-A1",
        unitId: unit1PreA1,
        category: "unit_exam",
        passScore: 70,
        timeLimitMinutes: 10,
        xpReward: 50,
        questionsJson: JSON.stringify([
          {
            id: 1,
            type: "multiple_choice",
            promptEn: "Which letter comes after 'M'?",
            promptAr: "ما هو الحرف الذي يأتي بعد حرف 'M'؟",
            options: ["L", "N", "O", "P"],
            correctIndex: 1,
            explanationAr: "الترتيب الأبجدي: L, M, N, O. الحرف بعد M هو N.",
          },
          {
            id: 2,
            type: "multiple_choice",
            promptEn: "Which sound does 'SH' make in 'Ship'?",
            promptAr: "ما هو صوت التركيب 'SH' في كلمة 'Ship'؟",
            options: ["صوت السين (s)", "صوت الشين (sh)", "صوت التاء (t)", "صوت الكاف (k)"],
            correctIndex: 1,
            explanationAr: "حرفي SH يُنطقان بصوت الشين (ش) مثل Ship و Shop.",
          },
          {
            id: 3,
            type: "multiple_choice",
            promptEn: "Which word starts with a vowel?",
            promptAr: "أي من هذه الكلمات تبدأ بحرف علة (متحرك)؟",
            options: ["Cat", "Dog", "Apple", "Fish"],
            correctIndex: 2,
            explanationAr: "Apple تبدأ بحرف A وهو أحد حروف العلة الخمسة (A, E, I, O, U).",
          },
        ]),
      },
    ]);

    return { message: "Database seeded successfully" };
  } catch (error) {
    console.error("Seeding error:", error);
    throw error;
  }
}
