import React from "react";

interface LevelBadgeProps {
  level: string;
  size?: "sm" | "md" | "lg";
}

export function LevelBadge({ level, size = "md" }: LevelBadgeProps) {
  const getBadgeStyle = (lvl: string) => {
    switch (lvl) {
      case "Pre-A1":
        return "bg-sky-500/15 text-sky-300 border-sky-500/30";
      case "A1":
        return "bg-blue-500/15 text-blue-300 border-blue-500/30";
      case "A2":
        return "bg-indigo-500/15 text-indigo-300 border-indigo-500/30";
      case "B1":
        return "bg-violet-500/15 text-violet-300 border-violet-500/30";
      case "B2":
        return "bg-purple-500/15 text-purple-300 border-purple-500/30";
      case "C1":
        return "bg-fuchsia-500/15 text-fuchsia-300 border-fuchsia-500/30";
      case "C2":
        return "bg-rose-500/15 text-rose-300 border-rose-500/30";
      default:
        return "bg-slate-700/30 text-slate-300 border-slate-600/30";
    }
  };

  const sizeClasses = {
    sm: "px-2 py-0.5 text-[10px]",
    md: "px-2.5 py-1 text-xs",
    lg: "px-3.5 py-1.5 text-sm",
  };

  return (
    <span
      className={`inline-flex items-center gap-1 font-semibold rounded-full border ${getBadgeStyle(
        level
      )} ${sizeClasses[size]}`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-80"></span>
      {level}
    </span>
  );
}
