"use client";

import React, { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import {
  BookOpen,
  GraduationCap,
  Sparkles,
  Volume2,
  MessageSquare,
  Award,
  Sun,
  Moon,
  Menu,
  X,
  User as UserIcon,
  LogOut,
  Flame,
  ShieldAlert,
  Compass,
  CheckCircle,
  HelpCircle,
  Bookmark,
  Gamepad2,
  FileText,
} from "lucide-react";

export function Navbar() {
  const pathname = usePathname();
  const { user, logout, theme, toggleTheme, quickLogin } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [demoDropdownOpen, setDemoDropdownOpen] = useState(false);

  const navLinks = [
    { href: "/", label: "الرئيسية", icon: Sparkles },
    { href: "/alphabet", label: "الحروف والأصوات", icon: BookOpen },
    { href: "/vocabulary", label: "المفردات والقاموس", icon: Bookmark },
    { href: "/grammar", label: "القواعد", icon: Compass },
    { href: "/conversations", label: "المحادثات", icon: MessageSquare },
    { href: "/listening", label: "الاستماع والنطق", icon: Volume2 },
    { href: "/reading-writing", label: "القراءة والكتابة", icon: FileText },
    { href: "/quizzes", label: "الاختبارات والألعاب", icon: Gamepad2 },
    { href: "/placement-test", label: "تحديد المستوى", icon: Award },
  ];

  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-slate-900/85 border-b border-slate-800 text-white transition-colors duration-200">
      {/* Top Banner: Quick Demo Bar */}
      <div className="bg-gradient-to-r from-indigo-900/60 via-purple-900/60 to-blue-900/60 border-b border-indigo-500/20 text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2 text-indigo-200">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>منصة عبود لتعلّم الإنجليزية من الصفر حتى الاحتراف الكامل</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-400 text-xs hidden sm:inline">تبديل الحساب التجريبي:</span>
            <button
              onClick={() => quickLogin("student")}
              className="px-2 py-0.5 rounded bg-blue-600/30 hover:bg-blue-600/50 text-blue-200 border border-blue-500/30 transition text-xs"
            >
              طالب (محمد)
            </button>
            <button
              onClick={() => quickLogin("teacher")}
              className="px-2 py-0.5 rounded bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/30 transition text-xs"
            >
              معلمة (سارة)
            </button>
            <button
              onClick={() => quickLogin("admin")}
              className="px-2 py-0.5 rounded bg-amber-600/30 hover:bg-amber-600/50 text-amber-200 border border-amber-500/30 transition text-xs font-medium"
            >
              المدير (الأستاذ عبود)
            </button>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/25 group-hover:scale-105 transition-transform duration-200 border border-indigo-400/30">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg bg-gradient-to-r from-blue-400 via-indigo-300 to-purple-400 bg-clip-text text-transparent">
                منصة عَبّود
              </span>
              <span className="text-[10px] text-slate-400 tracking-wider">ABOUD ENGLISH</span>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.slice(0, 6).map((link) => {
              const Icon = link.icon;
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
                    isActive
                      ? "bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 shadow-sm shadow-indigo-500/10"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                  }`}
                >
                  <Icon className="w-4 h-4 text-indigo-400" />
                  <span>{link.label}</span>
                </Link>
              );
            })}

            {/* Extra links in dropdown for cleaner look */}
            <div className="relative group">
              <button className="flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/60 transition">
                <span>المزيد</span>
                <span className="text-xs">▼</span>
              </button>
              <div className="absolute left-0 mt-1 w-48 rounded-xl bg-slate-900 border border-slate-800 shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-150 py-1.5 z-50">
                {navLinks.slice(6).map((link) => {
                  const Icon = link.icon;
                  return (
                    <Link
                      key={link.href}
                      href={link.href}
                      className="flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800"
                    >
                      <Icon className="w-4 h-4 text-indigo-400" />
                      <span>{link.label}</span>
                    </Link>
                  );
                })}
                <hr className="border-slate-800 my-1" />
                <Link
                  href="/favorites"
                  className="flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800"
                >
                  <Bookmark className="w-4 h-4 text-amber-400" />
                  <span>كلماتي المفضلة</span>
                </Link>
                <Link
                  href="/certificates"
                  className="flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800"
                >
                  <Award className="w-4 h-4 text-emerald-400" />
                  <span>الشهادات</span>
                </Link>
              </div>
            </div>
          </nav>

          {/* Right Actions (XP, User, Theme, Mobile toggle) */}
          <div className="flex items-center gap-2.5">
            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              title="تبديل المظهر"
              className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition border border-slate-700/50"
            >
              {theme === "dark" ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
            </button>

            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800/90 border border-slate-700 hover:border-indigo-500/50 transition"
                >
                  {/* Streak and XP badges */}
                  <div className="flex items-center gap-1 text-amber-400 text-xs font-semibold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20">
                    <Flame className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{user.streakDays}</span>
                  </div>

                  <div className="flex items-center gap-1 text-indigo-300 text-xs font-medium bg-indigo-500/10 px-2 py-0.5 rounded-full border border-indigo-500/20">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{user.xp} XP</span>
                  </div>

                  <div className="text-right hidden md:block">
                    <p className="text-xs font-medium text-white">{user.name}</p>
                    <p className="text-[10px] text-indigo-400">{user.currentLevel} • {user.role === "admin" ? "المدير" : user.role === "teacher" ? "معلم" : "طالب"}</p>
                  </div>
                </button>

                {/* Dropdown Menu */}
                {userDropdownOpen && (
                  <div
                    className="absolute left-0 mt-2 w-56 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl py-2 z-50 animate-in fade-in duration-100"
                    onClick={() => setUserDropdownOpen(false)}
                  >
                    <div className="px-4 py-2 border-b border-slate-800">
                      <p className="text-sm font-semibold text-white">{user.name}</p>
                      <p className="text-xs text-slate-400 truncate">{user.email}</p>
                      <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-medium bg-indigo-600/30 text-indigo-300 border border-indigo-500/20">
                        المستوى الحالي: {user.currentLevel}
                      </span>
                    </div>

                    <Link
                      href="/dashboard"
                      className="flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800"
                    >
                      <UserIcon className="w-4 h-4 text-indigo-400" />
                      <span>لوحة الطالب</span>
                    </Link>

                    <Link
                      href="/progress"
                      className="flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800"
                    >
                      <CheckCircle className="w-4 h-4 text-emerald-400" />
                      <span>سجل التقدم والإنجازات</span>
                    </Link>

                    <Link
                      href="/favorites"
                      className="flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800"
                    >
                      <Bookmark className="w-4 h-4 text-amber-400" />
                      <span>مفرداتي ومراجعة البطاقات</span>
                    </Link>

                    <Link
                      href="/certificates"
                      className="flex items-center gap-2.5 px-4 py-2 text-sm text-slate-300 hover:text-white hover:bg-slate-800"
                    >
                      <Award className="w-4 h-4 text-purple-400" />
                      <span>الشهادات المكتسبة</span>
                    </Link>

                    {(user.role === "admin" || user.role === "teacher") && (
                      <Link
                        href="/admin"
                        className="flex items-center gap-2.5 px-4 py-2 text-sm text-amber-300 hover:text-amber-200 hover:bg-amber-950/30 border-t border-slate-800"
                      >
                        <ShieldAlert className="w-4 h-4 text-amber-400" />
                        <span>لوحة إدارة المنصة</span>
                      </Link>
                    )}

                    <button
                      onClick={logout}
                      className="w-full text-right flex items-center gap-2.5 px-4 py-2 text-sm text-red-400 hover:text-red-300 hover:bg-red-950/30 border-t border-slate-800"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>تسجيل الخروج</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link
                  href="/auth/login"
                  className="px-3 py-1.5 text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800 rounded-lg transition"
                >
                  تسجيل الدخول
                </Link>
                <Link
                  href="/auth/register"
                  className="px-4 py-1.5 text-sm font-medium text-white bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 rounded-xl shadow-lg shadow-indigo-600/30 transition transform hover:-translate-y-0.5"
                >
                  ابدأ مجاناً
                </Link>
              </div>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 border-b border-slate-800 px-4 pt-2 pb-6 space-y-1 animate-in slide-in-from-top-2">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                  isActive
                    ? "bg-indigo-600/30 text-indigo-300 border border-indigo-500/30"
                    : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                <Icon className="w-4 h-4 text-indigo-400" />
                <span>{link.label}</span>
              </Link>
            );
          })}

          <div className="pt-3 border-t border-slate-800 grid grid-cols-2 gap-2">
            <Link
              href="/favorites"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-slate-800 text-xs text-amber-300"
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span>المفضلة</span>
            </Link>
            <Link
              href="/certificates"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-slate-800 text-xs text-emerald-300"
            >
              <Award className="w-3.5 h-3.5" />
              <span>الشهادات</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
